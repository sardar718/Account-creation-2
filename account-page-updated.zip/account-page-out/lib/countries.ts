export interface Country {
  name: string
  code: string   // e.g. "+52"
  iso: string    // e.g. "MX"
  digits: number // expected local number length
  flag: string
}

export const COUNTRIES: Country[] = [
  { name: "Mexico",         code: "+52",  iso: "MX", digits: 10, flag: "🇲🇽" },
  { name: "United States",  code: "+1",   iso: "US", digits: 10, flag: "🇺🇸" },
  { name: "Brazil",         code: "+55",  iso: "BR", digits: 11, flag: "🇧🇷" },
  { name: "United Kingdom", code: "+44",  iso: "GB", digits: 10, flag: "🇬🇧" },
  { name: "India",          code: "+91",  iso: "IN", digits: 10, flag: "🇮🇳" },
  { name: "Germany",        code: "+49",  iso: "DE", digits: 11, flag: "🇩🇪" },
  { name: "France",         code: "+33",  iso: "FR", digits: 9,  flag: "🇫🇷" },
  { name: "Spain",          code: "+34",  iso: "ES", digits: 9,  flag: "🇪🇸" },
  { name: "Italy",          code: "+39",  iso: "IT", digits: 10, flag: "🇮🇹" },
  { name: "Australia",      code: "+61",  iso: "AU", digits: 9,  flag: "🇦🇺" },
  { name: "Canada",         code: "+1",   iso: "CA", digits: 10, flag: "🇨🇦" },
  { name: "Argentina",      code: "+54",  iso: "AR", digits: 10, flag: "🇦🇷" },
  { name: "Colombia",       code: "+57",  iso: "CO", digits: 10, flag: "🇨🇴" },
  { name: "Chile",          code: "+56",  iso: "CL", digits: 9,  flag: "🇨🇱" },
  { name: "Peru",           code: "+51",  iso: "PE", digits: 9,  flag: "🇵🇪" },
  { name: "Netherlands",    code: "+31",  iso: "NL", digits: 9,  flag: "🇳🇱" },
  { name: "Portugal",       code: "+351", iso: "PT", digits: 9,  flag: "🇵🇹" },
  { name: "Poland",         code: "+48",  iso: "PL", digits: 9,  flag: "🇵🇱" },
  { name: "Turkey",         code: "+90",  iso: "TR", digits: 10, flag: "🇹🇷" },
  { name: "South Africa",   code: "+27",  iso: "ZA", digits: 9,  flag: "🇿🇦" },
  { name: "Nigeria",        code: "+234", iso: "NG", digits: 10, flag: "🇳🇬" },
  { name: "Japan",          code: "+81",  iso: "JP", digits: 10, flag: "🇯🇵" },
  { name: "South Korea",    code: "+82",  iso: "KR", digits: 10, flag: "🇰🇷" },
  { name: "China",          code: "+86",  iso: "CN", digits: 11, flag: "🇨🇳" },
  { name: "Indonesia",      code: "+62",  iso: "ID", digits: 10, flag: "🇮🇩" },
  { name: "Pakistan",       code: "+92",  iso: "PK", digits: 10, flag: "🇵🇰" },
  { name: "Philippines",    code: "+63",  iso: "PH", digits: 10, flag: "🇵🇭" },
  { name: "Russia",         code: "+7",   iso: "RU", digits: 10, flag: "🇷🇺" },
  { name: "Saudi Arabia",   code: "+966", iso: "SA", digits: 9,  flag: "🇸🇦" },
  { name: "UAE",            code: "+971", iso: "AE", digits: 9,  flag: "🇦🇪" },
]

export const DEFAULT_COUNTRY = COUNTRIES[0] // Mexico
