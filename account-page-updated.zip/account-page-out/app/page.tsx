"use client"

import { AutomationBox } from "@/components/automation-box"
import { CustomSignupBox } from "@/components/custom-signup-box"
import { Bot, UserPlus } from "lucide-react"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* ---- Section 1: OTP Batch Bot ---- */}
        <header className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Bot className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-balance text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            LoginGov
          </h1>
          <p className="mt-1.5 text-pretty text-sm text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            3 independent OTP bot slots. Each signs up, confirms email, sets password, selects 2FA, enters phone, and resends OTP.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <AutomationBox boxId={1} />
          <AutomationBox boxId={2} />
          <AutomationBox boxId={3} />
        </div>

        {/* Divider */}
        <div className="my-10 flex items-center gap-4">
          <div className="flex-1 border-t border-border" />
          <span className="text-xs font-medium text-muted-foreground">NEW WORKFLOW</span>
          <div className="flex-1 border-t border-border" />
        </div>

        {/* ---- Section 2: Custom Signup Bot ---- */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-accent">
            <UserPlus className="h-6 w-6 text-accent-foreground" />
          </div>
          <h2 className="text-balance text-xl font-bold tracking-tight text-foreground sm:text-2xl">
            WalMart
          </h2>
          <p className="mt-1.5 text-pretty text-sm text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            Auto-fills random name, @gmail.com email, phone with country code, strong password, solves captcha, and submits.
            Just paste the signup URL.
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <CustomSignupBox />
        </div>

        {/* Footer */}
        <footer className="mt-10">
          <div className="rounded-lg border border-border bg-card p-4 max-w-2xl mx-auto">
            <p className="text-xs font-medium text-card-foreground mb-1.5">How it works</p>
            <ul className="flex flex-col gap-1 text-[11px] text-muted-foreground leading-relaxed">
              <li><span className="font-semibold text-card-foreground">LoginGov (top):</span> Enter URL + phone numbers. Auto creates temp email, signs up, confirms, sets password, 2FA, sends OTP and resends N times.</li>
              <li><span className="font-semibold text-card-foreground">WalMart (bottom):</span> Just paste signup URL. Auto-generates random name, @gmail.com email, phone, password, solves captcha, and submits.</li>
              <li>Both bots auto-generate temp email via Mail.tm (fallback: Tempmail.lol, 1secmail) if no email is provided.</li>
              <li>Captcha support: math captcha (3+5=?), text captcha (type the word), and tick button detection. Does NOT solve image/reCAPTCHA.</li>
            </ul>
          </div>
        </footer>
      </div>
    </main>
  )
}
