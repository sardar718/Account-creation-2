import { generateText } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const { imageBase64 } = await req.json()

    if (!imageBase64) {
      return Response.json({ error: "No image provided" }, { status: 400 })
    }

    // Use AI vision model to read the captcha text
    const result = await generateText({
      model: "openai/gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `You are a captcha reader. Look at this captcha image and read the exact text/letters shown in it.

RULES:
- Output ONLY the letters/characters you see, nothing else
- Preserve exact case: uppercase letters must be uppercase, lowercase must be lowercase
- Do NOT add any spaces, explanations, quotes, or extra characters
- If a letter looks like uppercase (bigger, different style), treat it as uppercase
- If a letter looks like lowercase (smaller), treat it as lowercase
- Read left to right
- Just output the raw characters, for example: HJujb

What are the exact characters in this captcha image?`,
            },
            {
              type: "image",
              image: imageBase64.startsWith("data:")
                ? imageBase64
                : `data:image/png;base64,${imageBase64}`,
            },
          ],
        },
      ],
    })

    // Clean the response - remove any whitespace, quotes, or extra text
    const raw = result.text.trim()
    // Extract only alphanumeric characters (the captcha answer)
    const cleaned = raw.replace(/[^a-zA-Z0-9]/g, "")

    return Response.json({
      success: true,
      answer: cleaned,
      raw: raw,
    })
  } catch (err) {
    return Response.json(
      {
        success: false,
        error: `Captcha solve failed: ${err instanceof Error ? err.message : "Unknown error"}`,
      },
      { status: 500 }
    )
  }
}
