import { NextResponse } from "next/server"
import puppeteer from "puppeteer-core"
import chromium from "@sparticuz/chromium"

export const maxDuration = 60

interface AutomateRequest {
  url: string
  email: string
  reuseBrowser?: boolean
}

interface StepResult {
  step: string
  status: "success" | "failed"
  detail: string
}

export async function POST(req: Request) {
  const steps: StepResult[] = []
  let browser = null

  try {
    const body = (await req.json()) as AutomateRequest
    const { url, email } = body

    if (!url || !email) {
      return NextResponse.json(
        { success: false, error: "URL and email are required.", steps },
        { status: 400 }
      )
    }

    // Validate URL
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { success: false, error: "Invalid URL provided.", steps },
        { status: 400 }
      )
    }

    // Step 1: Launch browser
    steps.push({ step: "Launching browser", status: "success", detail: "Headless Chrome started" })

    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: true,
    })

    const page = await browser.newPage()
    await page.setViewport({ width: 1280, height: 800 })
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
    )

    // Step 2: Navigate to URL
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 })
      steps.push({
        step: "Navigating to page",
        status: "success",
        detail: `Loaded: ${page.url()}`,
      })
    } catch {
      steps.push({
        step: "Navigating to page",
        status: "failed",
        detail: "Could not load the page. It may be down or blocking automated access.",
      })
      return NextResponse.json({ success: false, error: "Failed to load the page.", steps })
    }

    // Step 3: Find the email input field
    const emailSelectors = [
      'input[type="email"]',
      'input[name="email"]',
      'input[name*="email" i]',
      'input[id*="email" i]',
      'input[placeholder*="email" i]',
      'input[autocomplete="email"]',
      'input[name="username"]',
      'input[name="login"]',
    ]

    let emailInput = null
    let matchedSelector = ""

    for (const selector of emailSelectors) {
      emailInput = await page.$(selector)
      if (emailInput) {
        matchedSelector = selector
        break
      }
    }

    if (!emailInput) {
      steps.push({
        step: "Finding email field",
        status: "failed",
        detail: "Could not find an email input field on this page.",
      })

      // Take a screenshot so user can see what the page looks like
      const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
      await browser.close()

      return NextResponse.json({
        success: false,
        error: "No email input field found on the page.",
        steps,
        screenshot: `data:image/jpeg;base64,${screenshot}`,
      })
    }

    steps.push({
      step: "Finding email field",
      status: "success",
      detail: `Found email field via: ${matchedSelector}`,
    })

    // Step 4: Clear the field and type the email
    await emailInput.click({ clickCount: 3 })
    await emailInput.type(email, { delay: 50 })
    steps.push({
      step: "Filling email",
      status: "success",
      detail: `Typed: ${email}`,
    })

    // Step 5: Find and check the "I accept terms / login rules" checkbox
    // This runs entirely inside the browser to avoid JSHandle/ElementHandle issues
    const checkboxResult = await page.evaluate(() => {
      const keywords = [
        "accept", "agree", "terms", "conditions", "privacy", "policy",
        "rules", "read", "consent", "tos", "i have read", "i read",
        "login rules", "login rule"
      ]

      // Helper: check if text contains any keyword
      const matchesKeyword = (text: string) => {
        const lower = text.toLowerCase().trim()
        return keywords.some((k) => lower.includes(k))
      }

      // Strategy 1: Direct attribute selectors on checkboxes
      const attrSelectors = [
        'input[type="checkbox"][name*="term" i]',
        'input[type="checkbox"][name*="agree" i]',
        'input[type="checkbox"][name*="accept" i]',
        'input[type="checkbox"][name*="policy" i]',
        'input[type="checkbox"][name*="consent" i]',
        'input[type="checkbox"][name*="tos" i]',
        'input[type="checkbox"][name*="rule" i]',
        'input[type="checkbox"][name*="login" i]',
        'input[type="checkbox"][id*="term" i]',
        'input[type="checkbox"][id*="agree" i]',
        'input[type="checkbox"][id*="accept" i]',
        'input[type="checkbox"][id*="policy" i]',
        'input[type="checkbox"][id*="consent" i]',
        'input[type="checkbox"][id*="tos" i]',
        'input[type="checkbox"][id*="rule" i]',
      ]

      for (const sel of attrSelectors) {
        const cb = document.querySelector(sel) as HTMLInputElement | null
        if (cb) {
          if (!cb.checked) cb.click()
          return { found: true, method: `attribute: ${sel}` }
        }
      }

      // Strategy 2: Labels wrapping or linked to checkboxes
      const labels = Array.from(document.querySelectorAll("label"))
      for (const label of labels) {
        const text = label.innerText || label.textContent || ""
        if (matchesKeyword(text)) {
          // Checkbox inside the label
          const cb = label.querySelector('input[type="checkbox"]') as HTMLInputElement | null
          if (cb) {
            if (!cb.checked) cb.click()
            return { found: true, method: "label wrapping checkbox" }
          }
          // Checkbox linked via "for" attribute
          const forId = label.getAttribute("for")
          if (forId) {
            const linked = document.getElementById(forId) as HTMLInputElement | null
            if (linked && linked.type === "checkbox") {
              if (!linked.checked) linked.click()
              return { found: true, method: "label[for] linked checkbox" }
            }
          }
          // Sometimes clicking the label itself toggles a hidden checkbox
          label.click()
          // Verify if a checkbox inside or linked got checked
          const cbAfter = label.querySelector('input[type="checkbox"]') as HTMLInputElement | null
          if (cbAfter && cbAfter.checked) {
            return { found: true, method: "label click toggled checkbox" }
          }
        }
      }

      // Strategy 3: Any checkbox near text containing keywords (parent/sibling traversal)
      const allCheckboxes = Array.from(document.querySelectorAll('input[type="checkbox"]'))
      for (const cb of allCheckboxes) {
        // Walk up parents up to 5 levels
        let parent: HTMLElement | null = cb.parentElement
        for (let i = 0; i < 5 && parent; i++) {
          const parentText = parent.innerText || parent.textContent || ""
          if (matchesKeyword(parentText)) {
            if (!(cb as HTMLInputElement).checked) (cb as HTMLInputElement).click()
            return { found: true, method: "parent text match" }
          }
          parent = parent.parentElement
        }
        // Check next sibling text
        const sibling = cb.nextElementSibling || cb.nextSibling
        if (sibling) {
          const sibText = (sibling as HTMLElement).innerText || sibling.textContent || ""
          if (matchesKeyword(sibText)) {
            if (!(cb as HTMLInputElement).checked) (cb as HTMLInputElement).click()
            return { found: true, method: "sibling text match" }
          }
        }
      }

      // Strategy 4: Custom checkbox elements (div/span role=checkbox or clickable)
      const customSelectors = [
        '[role="checkbox"]',
        '.checkbox',
        '[class*="checkbox" i]',
        '[class*="check-box" i]',
      ]
      for (const sel of customSelectors) {
        const els = Array.from(document.querySelectorAll(sel))
        for (const el of els) {
          let container: HTMLElement | null = el as HTMLElement
          for (let i = 0; i < 5 && container; i++) {
            const containerText = container.innerText || container.textContent || ""
            if (matchesKeyword(containerText)) {
              (el as HTMLElement).click()
              return { found: true, method: `custom element: ${sel}` }
            }
            container = container.parentElement
          }
        }
      }

      return { found: false, method: "none" }
    })

    if (checkboxResult.found) {
      steps.push({
        step: "Accepting terms checkbox",
        status: "success",
        detail: `Checked terms/rules checkbox (${checkboxResult.method})`,
      })
    } else {
      steps.push({
        step: "Accepting terms checkbox",
        status: "success",
        detail: "No terms checkbox found on page (may not be required).",
      })
    }

    // Small delay after checking to let any JS handlers fire
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Step 6: Find and click the submit button
    // Try Puppeteer ElementHandle first for standard selectors
    const standardSubmitSelectors = [
      'button[type="submit"]',
      'input[type="submit"]',
    ]

    let submitButton = null
    for (const selector of standardSubmitSelectors) {
      submitButton = await page.$(selector)
      if (submitButton) break
    }

    if (submitButton) {
      // Use native Puppeteer click for ElementHandle
      try {
        await Promise.all([
          page.waitForNavigation({ timeout: 10000 }).catch(() => {}),
          submitButton.click(),
        ])
        steps.push({
          step: "Clicking submit",
          status: "success",
          detail: "Form submitted successfully.",
        })
      } catch {
        steps.push({
          step: "Clicking submit",
          status: "failed",
          detail: "Clicked submit but navigation may have failed.",
        })
      }
    } else {
      // Fallback: find button by text content using page.evaluate (avoids JSHandle click issues)
      const submitResult = await page.evaluate(() => {
        const buttonTexts = [
          "sign up", "signup", "create account", "register",
          "submit", "get started", "continue", "next", "join",
          "create", "start", "send", "get code", "get otp",
          "request", "verify"
        ]
        const candidates = Array.from(
          document.querySelectorAll("button, input[type='submit'], a[role='button'], a.btn, a.button, [role='button']")
        )
        for (const btn of candidates) {
          const text = ((btn as HTMLElement).innerText || (btn as HTMLElement).textContent || "").toLowerCase().trim()
          const value = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
          if (buttonTexts.some((t) => text.includes(t) || value.includes(t))) {
            (btn as HTMLElement).click()
            return { found: true, text: text.substring(0, 40) }
          }
        }
        return { found: false, text: "" }
      })

      if (!submitResult.found) {
        const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
        steps.push({
          step: "Clicking submit",
          status: "failed",
          detail: "Could not find a submit button. Email was filled in but not submitted.",
        })
        await browser.close()
        return NextResponse.json({
          success: false,
          error: "Email filled but no submit button found. You may need to submit manually.",
          steps,
          screenshot: `data:image/jpeg;base64,${screenshot}`,
        })
      }

      // Wait for potential navigation after JS click
      await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
      steps.push({
        step: "Clicking submit",
        status: "success",
        detail: `Form submitted (button: "${submitResult.text}").`,
      })
    }

    // Short wait for any post-submit rendering
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Take final screenshot
    const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
    await browser.close()

    return NextResponse.json({
      success: true,
      steps,
      screenshot: `data:image/jpeg;base64,${screenshot}`,
      message: "Automation complete. Check your email for a confirmation link.",
    })
  } catch (err) {
    if (browser) await browser.close().catch(() => {})
    const errorMessage = err instanceof Error ? err.message : "Unknown error"
    return NextResponse.json(
      { success: false, error: `Automation failed: ${errorMessage}`, steps },
      { status: 500 }
    )
  }
}
