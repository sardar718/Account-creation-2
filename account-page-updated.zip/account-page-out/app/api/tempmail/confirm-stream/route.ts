import puppeteer from "puppeteer-core"
import chromium from "@sparticuz/chromium"

export const maxDuration = 300

interface ConfirmRequest {
  provider: "1secmail" | "mailtm" | "templol"
  login: string
  domain: string
  token?: string
  phone?: string
  resendCount?: number
}

interface MessageSummary {
  id: number | string
  from: string
  subject: string
}

function generateStrongPassword(): string {
  const length = 16
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"
  const lower = "abcdefghjkmnpqrstuvwxyz"
  const digits = "23456789"
  const symbols = "!@#$%&*_+-="
  const all = upper + lower + digits + symbols
  const mandatory = [
    upper[Math.floor(Math.random() * upper.length)],
    lower[Math.floor(Math.random() * lower.length)],
    digits[Math.floor(Math.random() * digits.length)],
    symbols[Math.floor(Math.random() * symbols.length)],
  ]
  const rest = Array.from({ length: length - mandatory.length }, () =>
    all[Math.floor(Math.random() * all.length)]
  )
  const chars = [...mandatory, ...rest]
  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[chars[i], chars[j]] = [chars[j], chars[i]]
  }
  return chars.join("")
}

export async function POST(req: Request) {
    const body = (await req.json()) as ConfirmRequest
    const { provider, login, domain, token, phone, resendCount: userResendCount } = body
    const totalResends = Math.max(0, Math.min((userResendCount ?? 9) - 1, 50)) // -1 because first send is separate

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: Record<string, unknown>) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`))
      }

      const sendStep = (step: string, status: string, detail: string) => {
        send({ type: "step", step, status, detail })
      }

      let password = ""

      try {
        // ---- STEP 1: Poll inbox ----
        sendStep("Polling temp inbox", "running", "Checking inbox for confirmation email...")

        let confirmLink: string | null = null
        let attempts = 0
        const maxAttempts = 12

        while (!confirmLink && attempts < maxAttempts) {
          attempts++
          await new Promise((r) => setTimeout(r, 5000))
          sendStep("Polling temp inbox", "running", `Attempt ${attempts}/${maxAttempts}...`)

          if (provider === "1secmail") {
            confirmLink = await poll1secmail(login, domain)
          } else if (provider === "mailtm") {
            if (!token) {
              sendStep("Polling temp inbox", "failed", "Mail.tm token missing.")
              send({ type: "done", success: false, error: "Mail.tm token required." })
              controller.close()
              return
            }
            confirmLink = await pollMailtm(token)
          } else if (provider === "templol") {
            if (!token) {
              sendStep("Polling temp inbox", "failed", "Tempmail.lol token missing.")
              send({ type: "done", success: false, error: "Tempmail.lol token required." })
              controller.close()
              return
            }
            confirmLink = await pollTemplol(token)
          }
        }

        if (!confirmLink) {
          sendStep("Polling temp inbox", "failed", `No email after ${maxAttempts * 5}s.`)
          send({ type: "done", success: false, error: "No confirmation email received." })
          controller.close()
          return
        }
        sendStep("Polling temp inbox", "success", "Confirmation email found!")

        // ---- STEP 2: Visit confirm link ----
        sendStep("Clicking confirm link", "running", "Launching browser...")

        const browser = await puppeteer.launch({
          args: chromium.args,
          executablePath: await chromium.executablePath(),
          headless: true,
        })

        try {
          const page = await browser.newPage()
          await page.setViewport({ width: 1280, height: 800 })
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
          )
          await page.goto(confirmLink, { waitUntil: "networkidle2", timeout: 30000 })
          await new Promise((r) => setTimeout(r, 3000))
          sendStep("Clicking confirm link", "success", `Visited: ${confirmLink.substring(0, 80)}...`)

          // ---- STEP 3: Fill password ----
          password = generateStrongPassword()
          await new Promise((r) => setTimeout(r, 2000))
          sendStep("Filling password", "running", "Looking for password fields...")

          const passwordResult = await page.evaluate((pw: string) => {
            const selectors = [
              'input[type="password"]',
              'input[name*="password" i]',
              'input[id*="password" i]',
              'input[placeholder*="password" i]',
              'input[autocomplete="new-password"]',
              'input[autocomplete="current-password"]',
            ]
            const allPw: HTMLInputElement[] = []
            for (const sel of selectors) {
              document.querySelectorAll(sel).forEach((el) => {
                const input = el as HTMLInputElement
                if (!allPw.includes(input)) allPw.push(input)
              })
            }
            if (allPw.length === 0) return { found: false, count: 0 }
            for (const field of allPw) {
              field.focus()
              field.value = ""
              field.dispatchEvent(new Event("input", { bubbles: true }))
              field.value = pw
              field.dispatchEvent(new Event("input", { bubbles: true }))
              field.dispatchEvent(new Event("change", { bubbles: true }))
              field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }))
            }
            return { found: true, count: allPw.length }
          }, password)

          if (passwordResult.found) {
            const pwField = await page.$('input[type="password"]')
            if (pwField) {
              await pwField.click({ clickCount: 3 })
              await pwField.type(password, { delay: 30 })
            }
            const allPwFields = await page.$$('input[type="password"]')
            if (allPwFields.length > 1) {
              for (let i = 1; i < allPwFields.length; i++) {
                await allPwFields[i].click({ clickCount: 3 })
                await allPwFields[i].type(password, { delay: 30 })
              }
            }
            sendStep("Filling password", "success", `Filled ${passwordResult.count} password field(s).`)
          } else {
            sendStep("Filling password", "failed", "No password field found.")
          }

          // ---- STEP 4: Click Continue after password ----
          await new Promise((r) => setTimeout(r, 500))
          const continueResult1 = await page.evaluate(() => {
            const texts = ["continue", "next", "submit", "create", "sign up", "register", "set password", "save", "confirm", "done", "proceed"]
            const btns = Array.from(document.querySelectorAll("button, input[type='submit'], a[role='button'], [role='button'], a.btn"))
            for (const btn of btns) {
              const t = ((btn as HTMLElement).innerText || "").toLowerCase().trim()
              const v = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
              if (texts.some((k) => t.includes(k) || v.includes(k))) { (btn as HTMLElement).click(); return { found: true, text: t.substring(0, 40) } }
            }
            const s = document.querySelector('button[type="submit"]') as HTMLElement
            if (s) { s.click(); return { found: true, text: "submit" } }
            return { found: false, text: "" }
          })
          if (continueResult1.found) {
            await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
            await new Promise((r) => setTimeout(r, 2000))
            sendStep("Submitting password", "success", `Clicked "${continueResult1.text}".`)
          } else {
            sendStep("Submitting password", "failed", "No Continue button found.")
          }

          // ---- STEP 5: Select "Text or voice message" 2FA ----
          await new Promise((r) => setTimeout(r, 2000))
          sendStep("Selecting 2FA method", "running", "Looking for Text or voice message...")

          const twoFaResult = await page.evaluate(() => {
            const kw = ["text or voice message", "text or voice", "sms text or phone call", "secure code by (sms)", "sms"]
            const m = (t: string) => { const l = t.toLowerCase().trim(); return kw.some((k) => l.includes(k)) }
            const cbs = Array.from(document.querySelectorAll('input[type="checkbox"], input[type="radio"]'))
            if (cbs.length >= 3) {
              const cb = cbs[2] as HTMLInputElement
              let p: HTMLElement | null = cb.parentElement
              let txt = ""
              for (let i = 0; i < 6 && p; i++) { txt = p.innerText || p.textContent || ""; if (m(txt)) break; p = p.parentElement }
              if (m(txt)) {
                if (!cb.checked) cb.click()
                const card = cb.closest("[class*='option' i], [class*='card' i], label, li, div[role='radio'], div[role='checkbox']")
                if (card) (card as HTMLElement).click()
                return { found: true, method: "3rd checkbox" }
              }
            }
            for (let i = 0; i < cbs.length; i++) {
              const cb = cbs[i] as HTMLInputElement
              let p: HTMLElement | null = cb.parentElement
              for (let j = 0; j < 6 && p; j++) {
                if (m(p.innerText || p.textContent || "")) {
                  if (!cb.checked) cb.click()
                  const card = cb.closest("[class*='option' i], [class*='card' i], label, li")
                  if (card) (card as HTMLElement).click()
                  return { found: true, method: `checkbox #${i + 1}` }
                }
                p = p.parentElement
              }
            }
            const cards = Array.from(document.querySelectorAll("label, div[role='button'], div[role='radio'], div[role='checkbox'], [class*='option' i], [class*='card' i], li"))
            for (const el of cards) {
              if (m((el as HTMLElement).innerText || "")) {
                (el as HTMLElement).click()
                const inner = el.querySelector('input[type="checkbox"], input[type="radio"]') as HTMLInputElement
                if (inner && !inner.checked) inner.click()
                return { found: true, method: "card" }
              }
            }
            return { found: false, method: "none" }
          })
          sendStep("Selecting 2FA method", twoFaResult.found ? "success" : "failed",
            twoFaResult.found ? `Selected "Text or voice message" (${twoFaResult.method}).` : "Could not find option.")

          // ---- STEP 6: Click Continue after 2FA ----
          await new Promise((r) => setTimeout(r, 500))
          const cont2 = await page.evaluate(() => {
            const texts = ["continue", "next", "submit", "confirm", "done", "proceed", "verify"]
            const btns = Array.from(document.querySelectorAll("button, input[type='submit'], a[role='button'], [role='button'], a.btn"))
            for (const btn of btns) {
              const t = ((btn as HTMLElement).innerText || "").toLowerCase().trim()
              const v = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
              if (texts.some((k) => t.includes(k) || v.includes(k))) { (btn as HTMLElement).click(); return { found: true, text: t.substring(0, 40) } }
            }
            return { found: false, text: "" }
          })
          if (cont2.found) {
            await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
            await new Promise((r) => setTimeout(r, 2000))
            sendStep("Continue after 2FA", "success", `Clicked "${cont2.text}".`)
          } else {
            sendStep("Continue after 2FA", "failed", "No Continue button found.")
          }

          // ---- STEP 7-8: Select Mexico + Enter phone ----
          if (phone) {
            await new Promise((r) => setTimeout(r, 3000))
            sendStep("Selecting Mexico", "running", "Looking for country selector...")

            const countryResult = await page.evaluate(() => {
              const selects = Array.from(document.querySelectorAll("select"))
              for (const sel of selects) {
                const options = Array.from(sel.options)
                for (const opt of options) {
                  const text = (opt.text || opt.label || "").toLowerCase()
                  const val = (opt.value || "").toLowerCase()
                  if (text.includes("mexico") || text.includes("méxico") || val === "mx" || val === "mex" || val.includes("+52") || text.includes("+52")) {
                    sel.value = opt.value
                    sel.dispatchEvent(new Event("change", { bubbles: true }))
                    sel.dispatchEvent(new Event("input", { bubbles: true }))
                    return { found: true, method: "select option", needsSearch: false }
                  }
                }
              }
              const triggers = Array.from(document.querySelectorAll("[class*='dropdown' i], [class*='select' i], [class*='country' i], [role='combobox'], [role='listbox'], button[aria-haspopup]"))
              for (const t of triggers) {
                const txt = ((t as HTMLElement).innerText || "").toLowerCase()
                if (txt.includes("country") || txt.includes("united states") || txt.includes("+1") || txt.includes("select") || t.getAttribute("aria-label")?.toLowerCase().includes("country")) {
                  (t as HTMLElement).click()
                  return { found: false, method: "opened dropdown", needsSearch: true }
                }
              }
              return { found: false, method: "none", needsSearch: false }
            })

            if (countryResult.found) {
              sendStep("Selecting Mexico", "success", `Selected Mexico (${countryResult.method}).`)
            } else if (countryResult.needsSearch) {
              await new Promise((r) => setTimeout(r, 1000))
              const searchInput = await page.$("input[placeholder*='search' i], input[placeholder*='country' i], input[aria-label*='search' i]")
              if (searchInput) { await searchInput.type("Mexico", { delay: 50 }); await new Promise((r) => setTimeout(r, 500)) }
              const clicked = await page.evaluate(() => {
                const items = Array.from(document.querySelectorAll("[role='option'], [class*='option' i], [class*='item' i], li"))
                for (const item of items) {
                  const t = ((item as HTMLElement).innerText || "").toLowerCase()
                  if (t.includes("mexico") || t.includes("méxico") || t.includes("+52")) { (item as HTMLElement).click(); return true }
                }
                return false
              })
              sendStep("Selecting Mexico", clicked ? "success" : "failed", clicked ? "Selected Mexico from dropdown." : "Could not find Mexico.")
            } else {
              sendStep("Selecting Mexico", "failed", "No country selector found.")
            }

            // Enter phone number
            await new Promise((r) => setTimeout(r, 1000))
            sendStep("Entering phone number", "running", `Typing ${phone}...`)
            const phoneResult = await page.evaluate((num: string) => {
              const sels = ['input[type="tel"]', 'input[name*="phone" i]', 'input[id*="phone" i]', 'input[placeholder*="phone" i]', 'input[placeholder*="number" i]', 'input[name*="number" i]', 'input[autocomplete="tel"]']
              for (const s of sels) {
                const input = document.querySelector(s) as HTMLInputElement
                if (input) {
                  input.focus(); input.value = ""; input.dispatchEvent(new Event("input", { bubbles: true }))
                  input.value = num; input.dispatchEvent(new Event("input", { bubbles: true })); input.dispatchEvent(new Event("change", { bubbles: true }))
                  return { found: true, selector: s }
                }
              }
              return { found: false, selector: "" }
            }, phone)
            if (phoneResult.found) {
              const pf = await page.$('input[type="tel"]') || await page.$('input[name*="phone" i]') || await page.$('input[placeholder*="phone" i]')
              if (pf) { await pf.click({ clickCount: 3 }); await pf.type(phone, { delay: 30 }) }
              sendStep("Entering phone number", "success", `Entered ${phone}.`)
            } else {
              sendStep("Entering phone number", "failed", "No phone input found.")
            }

            // ---- STEP 9: Click "Send code" (first OTP) ----
            await new Promise((r) => setTimeout(r, 500))
            sendStep("Sending OTP #1", "running", "Looking for Send Code button...")

            const sendCodeResult = await page.evaluate(() => {
              const texts = ["send code", "send sms", "send", "get code", "get otp", "request code", "verify", "continue", "next", "submit"]
              const btns = Array.from(document.querySelectorAll("button, input[type='submit'], a[role='button'], [role='button'], a.btn"))
              for (const btn of btns) {
                const t = ((btn as HTMLElement).innerText || "").toLowerCase().trim()
                const v = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
                if (texts.some((k) => t.includes(k) || v.includes(k))) { (btn as HTMLElement).click(); return { found: true, text: t.substring(0, 50) } }
              }
              return { found: false, text: "" }
            })

            let otpCount = 0
            if (sendCodeResult.found) {
              await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
              await new Promise((r) => setTimeout(r, 2000))
              otpCount = 1
              sendStep("Sending OTP #1", "success", `OTP #1 sent! ("${sendCodeResult.text}")`)
            } else {
              sendStep("Sending OTP #1", "failed", "Could not find Send Code button.")
            }

            // ---- STEP 10: Resend OTP (totalResends) more times, 11s delay each ----
            for (let i = 0; i < totalResends; i++) {
              const otpNum = otpCount + 1
              sendStep(`Sending OTP #${otpNum}`, "running", `Waiting 11 seconds before resend #${otpNum}...`)

              // Wait 11 seconds
              await new Promise((r) => setTimeout(r, 11000))

              sendStep(`Sending OTP #${otpNum}`, "running", `Clicking "Send another code"...`)

              // Specifically find the "Send another code" link/button
              // The screenshot shows it as a link <a> with text "Send another code" below the Submit button
              const resendResult = await page.evaluate(() => {
                // Priority 1: Exact text match for "Send another code" (the most specific)
                const exactTexts = ["send another code"]
                // Priority 2: Other resend-related texts (less specific)
                const fallbackTexts = [
                  "resend code", "resend", "send again", "try again",
                  "another code", "get another code", "send new code",
                  "request new code"
                ]

                // First, scan ALL <a> tags for exact "send another code"
                const allLinks = Array.from(document.querySelectorAll("a"))
                for (const link of allLinks) {
                  const text = (link.innerText || link.textContent || "").toLowerCase().trim()
                  if (exactTexts.some((t) => text.includes(t))) {
                    link.click()
                    return { found: true, text: text.substring(0, 50), method: "exact link" }
                  }
                }

                // Second, scan buttons for exact text
                const allButtons = Array.from(document.querySelectorAll("button"))
                for (const btn of allButtons) {
                  const text = (btn.innerText || btn.textContent || "").toLowerCase().trim()
                  if (exactTexts.some((t) => text.includes(t))) {
                    btn.click()
                    return { found: true, text: text.substring(0, 50), method: "exact button" }
                  }
                }

                // Third, scan any clickable element for exact text
                const allClickables = Array.from(
                  document.querySelectorAll("a, button, [role='button'], span[onclick], div[onclick]")
                )
                for (const el of allClickables) {
                  const text = ((el as HTMLElement).innerText || (el as HTMLElement).textContent || "").toLowerCase().trim()
                  if (exactTexts.some((t) => text.includes(t))) {
                    (el as HTMLElement).click()
                    return { found: true, text: text.substring(0, 50), method: "exact clickable" }
                  }
                }

                // Fourth, try fallback texts on links only (avoid matching "Submit" button)
                for (const link of allLinks) {
                  const text = (link.innerText || link.textContent || "").toLowerCase().trim()
                  if (fallbackTexts.some((t) => text.includes(t))) {
                    link.click()
                    return { found: true, text: text.substring(0, 50), method: "fallback link" }
                  }
                }

                // Fifth, try using Puppeteer-like XPath text search in JS
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
                let node
                while ((node = walker.nextNode())) {
                  const text = (node.textContent || "").toLowerCase().trim()
                  if (text.includes("send another code")) {
                    const parent = node.parentElement
                    if (parent) {
                      parent.click()
                      return { found: true, text: text.substring(0, 50), method: "text node parent" }
                    }
                  }
                }

                return { found: false, text: "", method: "none" }
              })

              if (resendResult.found) {
                // Wait for page to process the resend (don't use waitForNavigation as it may be AJAX)
                await new Promise((r) => setTimeout(r, 3000))
                otpCount++
                sendStep(`Sending OTP #${otpCount}`, "success", `OTP #${otpCount} sent! ("${resendResult.text}" via ${resendResult.method})`)
              } else {
                // Try using Puppeteer's native click as last resort
                const linkHandle = await page.$('a')
                const allLinks = await page.$$('a')
                let clicked = false
                for (const link of allLinks) {
                  const text = await link.evaluate((el) => (el.innerText || el.textContent || "").toLowerCase().trim())
                  if (text.includes("send another code") || text.includes("another code") || text.includes("resend")) {
                    await link.click()
                    await new Promise((r) => setTimeout(r, 3000))
                    otpCount++
                    clicked = true
                    sendStep(`Sending OTP #${otpCount}`, "success", `OTP #${otpCount} sent! (native click on "${text.substring(0, 40)}")`)
                    break
                  }
                }
                if (!clicked) {
                  sendStep(`Resend attempt #${otpNum}`, "failed", `Could not find "Send another code" button.`)
                }
                void linkHandle // suppress unused warning
              }
            }

            // ---- OTP SUMMARY ----
            sendStep("OTP resend complete", "success", `Number: ${phone} | OTP: ${otpCount} OTP(s) done`)

            // Take final screenshot
            const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
            send({
              type: "done",
              success: true,
              message: `Number: ${phone}\nOTP: ${otpCount} OTP done`,
              password,
              phone,
              otpCount,
              screenshot: `data:image/jpeg;base64,${screenshot}`,
            })
          } else {
            // No phone -- just finish
            const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
            send({
              type: "done",
              success: true,
              message: "Email confirmed, password set, 2FA selected.",
              password,
              screenshot: `data:image/jpeg;base64,${screenshot}`,
            })
          }

          await browser.close()
        } catch (err) {
          await browser.close().catch(() => {})
          send({ type: "done", success: false, error: `Error: ${err instanceof Error ? err.message : "Unknown"}` })
        }
      } catch (err) {
        send({ type: "done", success: false, error: `Failed: ${err instanceof Error ? err.message : "Unknown"}` })
      }

      controller.close()
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}

// ---- 1secmail polling ----
async function poll1secmail(login: string, domain: string): Promise<string | null> {
  try {
    const res = await fetch(`https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`)
    const messages = (await res.json()) as MessageSummary[]
    if (!messages || messages.length === 0) return null
    for (const msg of messages) {
      const detailRes = await fetch(`https://www.1secmail.com/api/v1/?action=readMessage&login=${login}&domain=${domain}&id=${msg.id}`)
      const detail = await detailRes.json()
      const body: string = detail.htmlBody || detail.body || detail.textBody || ""
      const link = extractConfirmLink(body)
      if (link) return link
    }
    return null
  } catch { return null }
}

// ---- Mail.tm polling ----
async function pollMailtm(token: string): Promise<string | null> {
  try {
    const res = await fetch("https://api.mail.tm/messages", { headers: { Authorization: `Bearer ${token}` } })
    const data = await res.json()
    const messages = data["hydra:member"] || data.member || data || []
    if (!Array.isArray(messages) || messages.length === 0) return null
    for (const msg of messages) {
      const msgRes = await fetch(`https://api.mail.tm/messages/${msg.id}`, { headers: { Authorization: `Bearer ${token}` } })
      const detail = await msgRes.json()
      const body: string = detail.html?.[0] || detail.text || ""
      const link = extractConfirmLink(body)
      if (link) return link
    }
    return null
  } catch { return null }
}

// ---- Tempmail.lol polling ----
async function pollTemplol(token: string): Promise<string | null> {
  try {
    const res = await fetch(`https://api.tempmail.lol/auth/${token}`)
    if (!res.ok) return null
    const data = await res.json()
    const emails = data.email || []
    if (!Array.isArray(emails) || emails.length === 0) return null
    for (const msg of emails) {
      const body: string = msg.html || msg.body || ""
      const link = extractConfirmLink(body)
      if (link) return link
    }
    return null
  } catch { return null }
}

// ---- Extract confirm link ----
function extractConfirmLink(body: string): string | null {
  if (!body) return null
  const anchorRegex = /<a\s[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi
  let match
  while ((match = anchorRegex.exec(body)) !== null) {
    const href = match[1]
    const text = match[2]?.toLowerCase() || ""
    const keywords = ["confirm", "verify", "activate", "validate", "click here", "complete registration", "confirm email", "confirmation_token", "email/confirm", "verify-email"]
    if (keywords.some((k) => `${href.toLowerCase()} ${text}`.includes(k))) return href.replace(/&amp;/g, "&")
  }
  const urlMatch = body.match(/https?:\/\/[^\s"'<>]+(?:confirm|verify|activate|validation|token)[^\s"'<>]*/gi)
  if (urlMatch?.length) return urlMatch[0].replace(/&amp;/g, "&")
  const lower = body.toLowerCase()
  if (lower.includes("confirm") || lower.includes("verify") || lower.includes("activate")) {
    const any = body.match(/<a\s[^>]*href=["'](https?:\/\/[^"']+)["']/i)
    if (any) return any[1].replace(/&amp;/g, "&")
  }
  return null
}
