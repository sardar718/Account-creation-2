import { NextResponse } from "next/server"

const BASE = "https://api.mail.tm"

function randomString(len: number) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  for (let i = 0; i < len; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

// POST: create a mail.tm account and return credentials + token
export async function POST() {
  try {
    // Step 1: Get available domains
    const domainRes = await fetch(`${BASE}/domains`)
    const domainData = await domainRes.json()
    const domains = domainData["hydra:member"] || domainData.member || domainData
    if (!Array.isArray(domains) || domains.length === 0) {
      return NextResponse.json({ success: false, error: "No domains available from Mail.tm" }, { status: 500 })
    }
    const domain = domains[0].domain

    // Step 2: Create account
    const username = randomString(10)
    const address = `${username}@${domain}`
    const password = randomString(16)

    const createRes = await fetch(`${BASE}/accounts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ address, password }),
    })

    if (!createRes.ok) {
      const errText = await createRes.text()
      return NextResponse.json(
        { success: false, error: `Mail.tm account creation failed: ${errText}` },
        { status: 500 }
      )
    }

    // Step 3: Get auth token
    const tokenRes = await fetch(`${BASE}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ address, password }),
    })

    if (!tokenRes.ok) {
      return NextResponse.json(
        { success: false, error: "Mail.tm token generation failed" },
        { status: 500 }
      )
    }

    const tokenData = await tokenRes.json()

    return NextResponse.json({
      success: true,
      email: address,
      login: username,
      domain,
      token: tokenData.token,
      provider: "mailtm",
    })
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    )
  }
}
