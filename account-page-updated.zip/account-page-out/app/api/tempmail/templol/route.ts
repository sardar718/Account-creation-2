import { NextResponse } from "next/server"

// Tempmail.lol API - free, no key required
// Docs: https://tempmail.lol/api-docs

export async function POST() {
  try {
    const res = await fetch("https://api.tempmail.lol/generate", { method: "GET" })
    if (!res.ok) {
      return NextResponse.json({ success: false, error: "Tempmail.lol generate failed" }, { status: 500 })
    }
    const data = await res.json()
    // Response: { address: "xxx@xxx.com", token: "..." }
    const email = data.address
    const token = data.token
    if (!email || !token) {
      return NextResponse.json({ success: false, error: "Invalid response from Tempmail.lol" }, { status: 500 })
    }
    const [login, domain] = email.split("@")
    return NextResponse.json({
      success: true,
      email,
      login,
      domain,
      token,
      provider: "templol",
    })
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    )
  }
}
