import { NextResponse } from "next/server"

const BASE = "https://www.1secmail.com/api/v1/"

// POST: generate a random email
export async function POST() {
  try {
    const res = await fetch(`${BASE}?action=genRandomMailbox&count=1`)
    const data = (await res.json()) as string[]
    if (!data || data.length === 0) {
      return NextResponse.json({ success: false, error: "Could not generate email" }, { status: 500 })
    }
    const email = data[0]
    const [login, domain] = email.split("@")
    return NextResponse.json({ success: true, email, login, domain, provider: "1secmail" })
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    )
  }
}
