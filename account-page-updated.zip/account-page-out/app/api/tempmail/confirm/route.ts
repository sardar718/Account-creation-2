import { NextResponse } from "next/server"
import puppeteer from "puppeteer-core"
import chromium from "@sparticuz/chromium"

export const maxDuration = 300

interface ConfirmRequest {
  provider: "1secmail" | "mailtm"
  login: string
  domain: string
  token?: string // only for mailtm
  phone?: string // phone number without country code
}

interface MessageSummary {
  id: number | string
  from: string
  subject: string
}

interface StepResult {
  step: string
  status: "success" | "failed"
  detail: string
}

// Generate a strong random password 12-20 characters
function generateStrongPassword(): string {
  const length = 16
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"
  const lower = "abcdefghjkmnpqrstuvwxyz"
  const digits = "23456789"
  const symbols = "!@#$%&*_+-="
  const all = upper + lower + digits + symbols

  // Ensure at least one of each type
  const mandatory = [
    upper[Math.floor(Math.random() * upper.length)],
    lower[Math.floor(Math.random() * lower.length)],
    digits[Math.floor(Math.random() * digits.length)],
    symbols[Math.floor(Math.random() * symbols.length)],
  ]

  const rest = Array.from({ length: length - mandatory.length }, () =>
    all[Math.floor(Math.random() * all.length)]
  )

  // Shuffle all characters
  const chars = [...mandatory, ...rest]
  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[chars[i], chars[j]] = [chars[j], chars[i]]
  }

  return chars.join("")
}

// Poll the temp inbox, find the confirmation email, extract the confirm link, visit it,
// then fill password + select "Text or voice message" 2FA
export async function POST(req: Request) {
  const steps: StepResult[] = []

  try {
    const body = (await req.json()) as ConfirmRequest
    const { provider, login, domain, token, phone } = body

    if (!provider || !login || !domain) {
      return NextResponse.json(
        { success: false, error: "Missing provider, login, or domain.", steps },
        { status: 400 }
      )
    }

    // ---- STEP 1: Poll inbox for confirmation email ----
    let confirmLink: string | null = null
    let attempts = 0
    const maxAttempts = 12

    while (!confirmLink && attempts < maxAttempts) {
      attempts++
      await new Promise((r) => setTimeout(r, 5000))

      if (provider === "1secmail") {
        confirmLink = await poll1secmail(login, domain)
      } else if (provider === "mailtm") {
        if (!token) {
          return NextResponse.json(
            { success: false, error: "Mail.tm token is required.", steps },
            { status: 400 }
          )
        }
        confirmLink = await pollMailtm(token)
      }
    }

    if (!confirmLink) {
      steps.push({
        step: "Polling temp inbox",
        status: "failed",
        detail: `No confirmation email received after ${maxAttempts * 5}s of polling.`,
      })
      return NextResponse.json({
        success: false,
        error: `No confirmation email received after ${maxAttempts * 5}s of polling.`,
        steps,
      })
    }

    steps.push({
      step: "Polling temp inbox",
      status: "success",
      detail: "Confirmation email found!",
    })

    // ---- STEP 2: Visit the confirm link using Puppeteer ----
    let browser = null
    try {
      browser = await puppeteer.launch({
        args: chromium.args,
        executablePath: await chromium.executablePath(),
        headless: true,
      })

      const page = await browser.newPage()
      await page.setViewport({ width: 1280, height: 800 })
      await page.setUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
      )

      await page.goto(confirmLink, { waitUntil: "networkidle2", timeout: 30000 })
      await new Promise((r) => setTimeout(r, 3000))

      steps.push({
        step: "Clicking confirm link",
        status: "success",
        detail: `Visited: ${confirmLink.substring(0, 80)}...`,
      })

      // ---- STEP 3: Fill password ----
      const password = generateStrongPassword()

      // Wait for any page transitions to settle
      await new Promise((r) => setTimeout(r, 2000))

      const passwordResult = await page.evaluate((pw: string) => {
        const selectors = [
          'input[type="password"]',
          'input[name*="password" i]',
          'input[id*="password" i]',
          'input[placeholder*="password" i]',
          'input[autocomplete="new-password"]',
          'input[autocomplete="current-password"]',
        ]

        // Find ALL password fields (sometimes there's password + confirm password)
        const allPasswordFields: HTMLInputElement[] = []
        for (const sel of selectors) {
          const els = document.querySelectorAll(sel)
          els.forEach((el) => {
            const input = el as HTMLInputElement
            if (!allPasswordFields.includes(input)) {
              allPasswordFields.push(input)
            }
          })
        }

        if (allPasswordFields.length === 0) {
          return { found: false, count: 0 }
        }

        // Fill all password fields with the same password
        for (const field of allPasswordFields) {
          // Clear existing value
          field.focus()
          field.value = ""
          // Dispatch events to trigger form validation
          field.dispatchEvent(new Event("input", { bubbles: true }))
          field.dispatchEvent(new Event("change", { bubbles: true }))

          // Set value character by character for better compatibility
          field.value = pw
          field.dispatchEvent(new Event("input", { bubbles: true }))
          field.dispatchEvent(new Event("change", { bubbles: true }))
          field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }))
        }

        return { found: true, count: allPasswordFields.length }
      }, password)

      if (passwordResult.found) {
        // Also use puppeteer's native type for the first password field as fallback
        const pwField = await page.$('input[type="password"]')
        if (pwField) {
          await pwField.click({ clickCount: 3 })
          await pwField.type(password, { delay: 30 })
        }

        // If there's a second password field (confirm), fill it too
        const allPwFields = await page.$$('input[type="password"]')
        if (allPwFields.length > 1) {
          for (let i = 1; i < allPwFields.length; i++) {
            await allPwFields[i].click({ clickCount: 3 })
            await allPwFields[i].type(password, { delay: 30 })
          }
        }

        steps.push({
          step: "Filling password",
          status: "success",
          detail: `Filled ${passwordResult.count} password field(s) with a strong ${password.length}-char password.`,
        })
      } else {
        steps.push({
          step: "Filling password",
          status: "failed",
          detail: "No password field found on the page (may appear on a different step).",
        })
      }

      // ---- STEP 4: Click Continue/Submit after password ----
      await new Promise((r) => setTimeout(r, 500))

      const continueResult1 = await page.evaluate(() => {
        const buttonTexts = [
          "continue", "next", "submit", "create", "sign up", "register",
          "set password", "save", "confirm", "done", "proceed"
        ]
        const candidates = Array.from(
          document.querySelectorAll(
            "button, input[type='submit'], a[role='button'], [role='button'], a.btn"
          )
        )
        for (const btn of candidates) {
          const text = ((btn as HTMLElement).innerText || (btn as HTMLElement).textContent || "").toLowerCase().trim()
          const value = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
          if (buttonTexts.some((t) => text.includes(t) || value.includes(t))) {
            (btn as HTMLElement).click()
            return { found: true, text: text.substring(0, 40) }
          }
        }
        // Also try submit buttons directly
        const submitBtn = document.querySelector('button[type="submit"]') as HTMLElement
        if (submitBtn) {
          submitBtn.click()
          return { found: true, text: "submit button" }
        }
        return { found: false, text: "" }
      })

      if (continueResult1.found) {
        // Wait for navigation or page change
        await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
        await new Promise((r) => setTimeout(r, 2000))

        steps.push({
          step: "Submitting password",
          status: "success",
          detail: `Clicked "${continueResult1.text}" after filling password.`,
        })
      } else {
        steps.push({
          step: "Submitting password",
          status: "failed",
          detail: "Could not find a Continue/Submit button after password.",
        })
      }

      // ---- STEP 5: Select "Text or voice message" 2FA option ----
      await new Promise((r) => setTimeout(r, 2000))

      const twoFaResult = await page.evaluate(() => {
        const targetKeywords = [
          "text or voice message",
          "text or voice",
          "sms text or phone call",
          "secure code by (sms)",
          "sms",
        ]
        const matchesTarget = (text: string) => {
          const lower = text.toLowerCase().trim()
          return targetKeywords.some((k) => lower.includes(k))
        }

        // --- Primary strategy: select the 3rd checkbox/radio by index ---
        // The page has 5 auth methods, and "Text or voice message" is the 3rd
        const allCheckboxes = Array.from(
          document.querySelectorAll('input[type="checkbox"], input[type="radio"]')
        )
        if (allCheckboxes.length >= 3) {
          const thirdCb = allCheckboxes[2] as HTMLInputElement
          // Verify the 3rd checkbox is near "text or voice" text
          let parent: HTMLElement | null = thirdCb.parentElement
          let nearbyText = ""
          for (let i = 0; i < 6 && parent; i++) {
            nearbyText = parent.innerText || parent.textContent || ""
            if (matchesTarget(nearbyText)) break
            parent = parent.parentElement
          }

          if (matchesTarget(nearbyText)) {
            if (!thirdCb.checked) thirdCb.click()
            // Also click the parent container/card in case it's a card-style selector
            const card = thirdCb.closest("[class*='option' i], [class*='card' i], label, li, div[role='radio'], div[role='checkbox']")
            if (card) (card as HTMLElement).click()
            return { found: true, method: "3rd checkbox (text or voice message)" }
          }

          // If the 3rd checkbox doesn't match the text, still try it
          // but also try the text-based fallback below
        }

        // --- Fallback: find the checkbox/card whose container text matches ---
        for (let i = 0; i < allCheckboxes.length; i++) {
          const cb = allCheckboxes[i] as HTMLInputElement
          let parent: HTMLElement | null = cb.parentElement
          for (let j = 0; j < 6 && parent; j++) {
            const parentText = parent.innerText || parent.textContent || ""
            if (matchesTarget(parentText)) {
              if (!cb.checked) cb.click()
              const card = cb.closest("[class*='option' i], [class*='card' i], label, li, div[role='radio'], div[role='checkbox']")
              if (card) (card as HTMLElement).click()
              return { found: true, method: `checkbox #${i + 1} matched by text` }
            }
            parent = parent.parentElement
          }
        }

        // --- Fallback 2: Clickable cards/divs with matching text ---
        const allCards = Array.from(
          document.querySelectorAll(
            "label, div[role='button'], div[role='radio'], div[role='checkbox'], [class*='option' i], [class*='card' i], [class*='choice' i], li"
          )
        )
        for (const el of allCards) {
          const text = (el as HTMLElement).innerText || (el as HTMLElement).textContent || ""
          if (matchesTarget(text)) {
            (el as HTMLElement).click()
            const innerCb = el.querySelector('input[type="checkbox"], input[type="radio"]') as HTMLInputElement
            if (innerCb && !innerCb.checked) innerCb.click()
            return { found: true, method: "card container with matching text" }
          }
        }

        // --- Fallback 3: Any clickable element with matching text ---
        const clickables = Array.from(document.querySelectorAll("a, button, span, p, h2, h3, h4, strong"))
        for (const el of clickables) {
          const text = (el as HTMLElement).innerText || (el as HTMLElement).textContent || ""
          if (matchesTarget(text)) {
            (el as HTMLElement).click()
            return { found: true, method: "clickable element with matching text" }
          }
        }

        return { found: false, method: "none" }
      })

      if (twoFaResult.found) {
        steps.push({
          step: "Selecting 2FA method",
          status: "success",
          detail: `Selected "Text or voice message" (${twoFaResult.method}).`,
        })
      } else {
        steps.push({
          step: "Selecting 2FA method",
          status: "failed",
          detail: "Could not find 'Text or voice message' option on the page.",
        })
      }

      // ---- STEP 6: Click Continue after selecting 2FA ----
      await new Promise((r) => setTimeout(r, 500))

      const continueResult2 = await page.evaluate(() => {
        const buttonTexts = [
          "continue", "next", "submit", "confirm", "done", "proceed", "verify"
        ]
        const candidates = Array.from(
          document.querySelectorAll(
            "button, input[type='submit'], a[role='button'], [role='button'], a.btn"
          )
        )
        for (const btn of candidates) {
          const text = ((btn as HTMLElement).innerText || (btn as HTMLElement).textContent || "").toLowerCase().trim()
          const value = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
          if (buttonTexts.some((t) => text.includes(t) || value.includes(t))) {
            (btn as HTMLElement).click()
            return { found: true, text: text.substring(0, 40) }
          }
        }
        return { found: false, text: "" }
      })

      if (continueResult2.found) {
        await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
        await new Promise((r) => setTimeout(r, 2000))

        steps.push({
          step: "Clicking continue after 2FA",
          status: "success",
          detail: `Clicked "${continueResult2.text}".`,
        })
      } else {
        steps.push({
          step: "Clicking continue after 2FA",
          status: "failed",
          detail: "Could not find Continue button after 2FA selection.",
        })
      }

      // ---- STEP 7: Select Mexico as country and enter phone number ----
      if (phone) {
        await new Promise((r) => setTimeout(r, 3000))

        // Try to select Mexico in a country dropdown/select
        const countryResult = await page.evaluate(() => {
          // Strategy 1: <select> element with country options
          const selects = Array.from(document.querySelectorAll("select"))
          for (const sel of selects) {
            const nameOrId = `${sel.name} ${sel.id} ${sel.className}`.toLowerCase()
            // Check if this looks like a country selector
            if (
              nameOrId.includes("country") ||
              nameOrId.includes("phone") ||
              nameOrId.includes("region") ||
              nameOrId.includes("code") ||
              nameOrId.includes("intl")
            ) {
              // Try to find Mexico option
              const options = Array.from(sel.options)
              for (const opt of options) {
                const text = (opt.text || opt.label || "").toLowerCase()
                const val = (opt.value || "").toLowerCase()
                if (
                  text.includes("mexico") ||
                  text.includes("méxico") ||
                  val === "mx" ||
                  val === "mex" ||
                  val.includes("+52") ||
                  text.includes("+52")
                ) {
                  sel.value = opt.value
                  sel.dispatchEvent(new Event("change", { bubbles: true }))
                  sel.dispatchEvent(new Event("input", { bubbles: true }))
                  return { found: true, method: "select option Mexico" }
                }
              }
            }
          }

          // Also try all selects (some don't have country-named attributes)
          for (const sel of selects) {
            const options = Array.from(sel.options)
            for (const opt of options) {
              const text = (opt.text || opt.label || "").toLowerCase()
              const val = (opt.value || "").toLowerCase()
              if (
                text.includes("mexico") ||
                text.includes("méxico") ||
                val === "mx" ||
                val === "mex"
              ) {
                sel.value = opt.value
                sel.dispatchEvent(new Event("change", { bubbles: true }))
                sel.dispatchEvent(new Event("input", { bubbles: true }))
                return { found: true, method: "select option Mexico (fallback)" }
              }
            }
          }

          // Strategy 2: Custom dropdown (click to open, then find Mexico)
          const dropdownTriggers = Array.from(
            document.querySelectorAll(
              "[class*='dropdown' i], [class*='select' i], [class*='country' i], [class*='phone-code' i], [role='combobox'], [role='listbox'], button[aria-haspopup]"
            )
          )
          for (const trigger of dropdownTriggers) {
            const text = ((trigger as HTMLElement).innerText || (trigger as HTMLElement).textContent || "").toLowerCase()
            // Check if it looks like a country/phone code selector
            if (
              text.includes("country") ||
              text.includes("united states") ||
              text.includes("+1") ||
              text.includes("select") ||
              trigger.getAttribute("aria-label")?.toLowerCase().includes("country")
            ) {
              (trigger as HTMLElement).click()
              return { found: false, method: "opened dropdown", needsSearch: true }
            }
          }

          return { found: false, method: "none", needsSearch: false }
        })

        if (countryResult.found) {
          steps.push({
            step: "Selecting Mexico",
            status: "success",
            detail: `Selected Mexico as country (${countryResult.method}).`,
          })
        } else if ((countryResult as { needsSearch?: boolean }).needsSearch) {
          // A custom dropdown was opened - now search for Mexico
          await new Promise((r) => setTimeout(r, 1000))

          // Try typing "Mexico" in any search/filter input that appeared
          const searchInput = await page.$("[class*='search' i] input, [role='combobox'] input, input[placeholder*='search' i], input[placeholder*='country' i], input[aria-label*='search' i]")
          if (searchInput) {
            await searchInput.type("Mexico", { delay: 50 })
            await new Promise((r) => setTimeout(r, 500))
          }

          // Click on Mexico option in the open dropdown
          const mexicoClicked = await page.evaluate(() => {
            const items = Array.from(
              document.querySelectorAll(
                "[role='option'], [class*='option' i], [class*='item' i], li, div[class*='country' i]"
              )
            )
            for (const item of items) {
              const text = ((item as HTMLElement).innerText || (item as HTMLElement).textContent || "").toLowerCase()
              if (text.includes("mexico") || text.includes("méxico") || text.includes("+52")) {
                (item as HTMLElement).click()
                return true
              }
            }
            return false
          })

          steps.push({
            step: "Selecting Mexico",
            status: mexicoClicked ? "success" : "failed",
            detail: mexicoClicked
              ? "Selected Mexico from custom dropdown."
              : "Could not find Mexico in dropdown options.",
          })
        } else {
          steps.push({
            step: "Selecting Mexico",
            status: "failed",
            detail: "Could not find a country selector on the page.",
          })
        }

        // ---- STEP 8: Enter the phone number ----
        await new Promise((r) => setTimeout(r, 1000))

        const phoneResult = await page.evaluate((num: string) => {
          const selectors = [
            'input[type="tel"]',
            'input[name*="phone" i]',
            'input[id*="phone" i]',
            'input[placeholder*="phone" i]',
            'input[name*="mobile" i]',
            'input[placeholder*="number" i]',
            'input[name*="number" i]',
            'input[autocomplete="tel"]',
            'input[autocomplete="tel-national"]',
          ]

          for (const sel of selectors) {
            const input = document.querySelector(sel) as HTMLInputElement
            if (input) {
              input.focus()
              input.value = ""
              input.dispatchEvent(new Event("input", { bubbles: true }))
              input.value = num
              input.dispatchEvent(new Event("input", { bubbles: true }))
              input.dispatchEvent(new Event("change", { bubbles: true }))
              input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }))
              return { found: true, selector: sel }
            }
          }
          return { found: false, selector: "" }
        }, phone)

        if (phoneResult.found) {
          // Also use Puppeteer native typing for better compatibility
          const phoneField = await page.$('input[type="tel"]') ||
            await page.$('input[name*="phone" i]') ||
            await page.$('input[id*="phone" i]') ||
            await page.$('input[placeholder*="phone" i]') ||
            await page.$('input[placeholder*="number" i]')

          if (phoneField) {
            await phoneField.click({ clickCount: 3 })
            await phoneField.type(phone, { delay: 30 })
          }

          steps.push({
            step: "Entering phone number",
            status: "success",
            detail: `Entered phone number (${phoneResult.selector}).`,
          })
        } else {
          steps.push({
            step: "Entering phone number",
            status: "failed",
            detail: "Could not find a phone number input on the page.",
          })
        }

        // ---- STEP 9: Click "Send code" button (first time) ----
        await new Promise((r) => setTimeout(r, 500))

        const sendCodeResult = await page.evaluate(() => {
          const buttonTexts = [
            "send code", "send sms", "send", "get code", "get otp",
            "request code", "verify", "continue", "next", "submit"
          ]
          const candidates = Array.from(
            document.querySelectorAll(
              "button, input[type='submit'], a[role='button'], [role='button'], a.btn"
            )
          )
          for (const btn of candidates) {
            const text = ((btn as HTMLElement).innerText || (btn as HTMLElement).textContent || "").toLowerCase().trim()
            const value = (btn as HTMLInputElement).value?.toLowerCase().trim() || ""
            if (buttonTexts.some((t) => text.includes(t) || value.includes(t))) {
              (btn as HTMLElement).click()
              return { found: true, text: text.substring(0, 40) }
            }
          }
          return { found: false, text: "" }
        })

        if (sendCodeResult.found) {
          await page.waitForNavigation({ timeout: 10000 }).catch(() => {})
          await new Promise((r) => setTimeout(r, 2000))

          steps.push({
            step: "Sending OTP #1",
            status: "success",
            detail: `First OTP sent! Clicked "${sendCodeResult.text}".`,
          })
        } else {
          steps.push({
            step: "Sending OTP #1",
            status: "failed",
            detail: "Could not find Send Code button.",
          })
        }

        // ---- STEP 10: Resend OTP 7 more times (total 8) with 11s delay ----
        let otpCount = sendCodeResult.found ? 1 : 0
        const totalResends = 7

        for (let i = 0; i < totalResends; i++) {
          // Wait 11 seconds before resending
          await new Promise((r) => setTimeout(r, 11000))

          const resendResult = await page.evaluate(() => {
            const resendTexts = [
              "send another code", "resend code", "resend", "send again",
              "try again", "new code", "another code", "get another code",
              "send new code", "request new code", "didn't get a code",
              "send code", "send sms", "get code",
            ]
            // Search across all clickable elements
            const candidates = Array.from(
              document.querySelectorAll(
                "button, a, input[type='submit'], [role='button'], span[class*='link' i], span[class*='btn' i], p > a, div > a"
              )
            )
            for (const el of candidates) {
              const text = ((el as HTMLElement).innerText || (el as HTMLElement).textContent || "").toLowerCase().trim()
              const value = (el as HTMLInputElement).value?.toLowerCase().trim() || ""
              if (resendTexts.some((t) => text.includes(t) || value.includes(t))) {
                (el as HTMLElement).click()
                return { found: true, text: text.substring(0, 50) }
              }
            }
            return { found: false, text: "" }
          })

          if (resendResult.found) {
            // Wait for any navigation/refresh
            await page.waitForNavigation({ timeout: 8000 }).catch(() => {})
            await new Promise((r) => setTimeout(r, 1500))
            otpCount++

            steps.push({
              step: `Sending OTP #${otpCount}`,
              status: "success",
              detail: `OTP #${otpCount} sent! (clicked "${resendResult.text}")`,
            })
          } else {
            steps.push({
              step: `Resend attempt #${i + 2}`,
              status: "failed",
              detail: "Could not find 'send another code' button.",
            })
          }
        }

        // Add summary step
        steps.push({
          step: "OTP resend complete",
          status: "success",
          detail: `Number: ${phone} | OTP: ${otpCount} OTP(s) sent`,
        })
      }

      // ---- Final screenshot ----
      const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
      const finalUrl = page.url()
      await browser.close()

      return NextResponse.json({
        success: true,
        message: `All done! ${phone ? `Number: ${phone} | OTP: sent ${steps.filter(s => s.step.startsWith("Sending OTP")).length} time(s)` : "Email confirmed, password set, 2FA selected."}`,
        confirmLink,
        finalUrl,
        password,
        steps,
        phone,
        otpCount: steps.filter(s => s.step.startsWith("Sending OTP") && s.status === "success").length,
        screenshot: `data:image/jpeg;base64,${screenshot}`,
      })
    } catch (err) {
      if (browser) await browser.close().catch(() => {})
      return NextResponse.json({
        success: false,
        error: `Confirm flow error: ${err instanceof Error ? err.message : "Unknown error"}`,
        confirmLink,
        steps,
      })
    }
  } catch (err) {
    return NextResponse.json(
      {
        success: false,
        error: `Confirm flow failed: ${err instanceof Error ? err.message : "Unknown error"}`,
        steps,
      },
      { status: 500 }
    )
  }
}

// ---- 1secmail: poll inbox and extract confirm link ----
async function poll1secmail(login: string, domain: string): Promise<string | null> {
  try {
    const listRes = await fetch(
      `https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`
    )
    const messages = (await listRes.json()) as MessageSummary[]

    if (!messages || messages.length === 0) return null

    for (const msg of messages) {
      const detailRes = await fetch(
        `https://www.1secmail.com/api/v1/?action=readMessage&login=${login}&domain=${domain}&id=${msg.id}`
      )
      const detail = await detailRes.json()
      const body: string = detail.htmlBody || detail.body || detail.textBody || ""

      const link = extractConfirmLink(body)
      if (link) return link
    }

    return null
  } catch {
    return null
  }
}

// ---- Mail.tm: poll inbox and extract confirm link ----
async function pollMailtm(token: string): Promise<string | null> {
  try {
    const res = await fetch("https://api.mail.tm/messages", {
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    const messages = data["hydra:member"] || data.member || data || []

    if (!Array.isArray(messages) || messages.length === 0) return null

    for (const msg of messages) {
      const msgRes = await fetch(`https://api.mail.tm/messages/${msg.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const detail = await msgRes.json()
      const body: string = detail.html?.[0] || detail.text || ""

      const link = extractConfirmLink(body)
      if (link) return link
    }

    return null
  } catch {
    return null
  }
}

// ---- Extract the confirm/verify link from email HTML or text ----
function extractConfirmLink(body: string): string | null {
  if (!body) return null

  const anchorRegex = /<a\s[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi
  let match
  while ((match = anchorRegex.exec(body)) !== null) {
    const href = match[1]
    const text = match[2]?.toLowerCase() || ""

    const keywords = [
      "confirm", "verify", "activate", "validate", "click here",
      "complete registration", "confirm email", "confirmation_token",
      "email/confirm", "verify-email", "activate-account"
    ]
    const combined = `${href.toLowerCase()} ${text}`
    if (keywords.some((k) => combined.includes(k))) {
      return href.replace(/&amp;/g, "&")
    }
  }

  const urlRegex = /https?:\/\/[^\s"'<>]+(?:confirm|verify|activate|validation|token)[^\s"'<>]*/gi
  const urlMatch = body.match(urlRegex)
  if (urlMatch && urlMatch.length > 0) {
    return urlMatch[0].replace(/&amp;/g, "&")
  }

  const lowerBody = body.toLowerCase()
  if (
    lowerBody.includes("confirm") ||
    lowerBody.includes("verify") ||
    lowerBody.includes("activate")
  ) {
    const anyLinkRegex = /<a\s[^>]*href=["'](https?:\/\/[^"']+)["']/i
    const anyMatch = body.match(anyLinkRegex)
    if (anyMatch) {
      return anyMatch[1].replace(/&amp;/g, "&")
    }
  }

  return null
}
