import puppeteer from "puppeteer-core"
import chromium from "@sparticuz/chromium"
// AI Vision solvers disabled until AI Gateway billing is configured
// import { generateText } from "ai"

export const maxDuration = 120

// ---- Random data generators ----
const FIRST_NAMES = [
  "James","Mary","Robert","Linda","Michael","Sarah","David","Jessica","Daniel","Emily",
  "Carlos","Sofia","Ahmed","Fatima","Wei","Yuki","Raj","Priya","Ivan","Olga",
  "Liam","Emma","Noah","Ava","Ethan","Mia","Lucas","Chloe","Mason","Lily",
  "Oliver","Zoe","Logan","Grace","Alex","Anna","Ryan","Clara","Jake","Maya",
]
const LAST_NAMES = [
  "Smith","Johnson","Brown","Garcia","Martinez","Anderson","Taylor","Thomas","Moore","Jackson",
  "Lopez","Harris","Clark","Lewis","Robinson","Walker","Young","Allen","King","Wright",
  "Scott","Green","Baker","Hill","Adams","Nelson","Carter","Mitchell","Perez","Turner",
  "Torres","Rivera","Flores","Gomez","Diaz","Reyes","Cruz","Morales","Mendoza","Ruiz",
]
const WORDS = [
  "box","car","sun","moon","star","fire","ice","wind","rock","tree",
  "wolf","hawk","bear","fox","deer","lion","eagle","shark","whale","tiger",
  "blue","red","gold","dark","bright","swift","bold","calm","wild","free",
  "hub","zen","neo","max","ace","pro","top","epic","nova","apex",
]
const COUNTRY_CODES = [
  { code: "+52", digits: 10 }, { code: "+55", digits: 11 }, { code: "+1", digits: 10 },
  { code: "+44", digits: 10 }, { code: "+91", digits: 10 }, { code: "+49", digits: 11 },
  { code: "+33", digits: 9 }, { code: "+34", digits: 9 },
  { code: "+39", digits: 10 }, { code: "+61", digits: 9 },
]
function randomFrom<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function generateEmail(): string {
  const base = randomFrom(FIRST_NAMES).toLowerCase()
  return `${base}${randomFrom(WORDS)}${randomFrom(WORDS)}${Math.floor(Math.random() * 999) + 1}@gmail.com`
}
function generatePhone(countryCode?: string, countryDigits?: number): string {
  const c = (countryCode && countryDigits)
    ? { code: countryCode, digits: countryDigits }
    : randomFrom(COUNTRY_CODES)
  let num = ""
  for (let i = 0; i < c.digits; i++) num += i === 0 ? String(Math.floor(Math.random() * 9) + 1) : String(Math.floor(Math.random() * 10))
  return `${c.code}${num}`
}
function generatePassword(): string {
  const u = "ABCDEFGHJKLMNPQRSTUVWXYZ", l = "abcdefghjkmnpqrstuvwxyz", d = "23456789", s = "!@#$%&*?"
  let p = u[Math.floor(Math.random() * u.length)] + l[Math.floor(Math.random() * l.length)] +
    d[Math.floor(Math.random() * d.length)] + s[Math.floor(Math.random() * s.length)]
  const all = u + l + d + s
  for (let i = 0; i < 12; i++) p += all[Math.floor(Math.random() * all.length)]
  return p.split("").sort(() => Math.random() - 0.5).join("")
}

export async function POST(req: Request) {
  const body = await req.json()
  const url = body.url as string
  const countryCode = (body.countryCode as string) || "+52"
  const countryDigits = (body.countryDigits as number) || 10

  if (!url) {
    return new Response(JSON.stringify({ error: "URL is required." }), { status: 400, headers: { "Content-Type": "application/json" } })
  }
  try { new URL(url) } catch {
    return new Response(JSON.stringify({ error: "Invalid URL." }), { status: 400, headers: { "Content-Type": "application/json" } })
  }

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    async start(controller) {
      function send(data: Record<string, unknown>) {
        try { controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`)) } catch { /* closed */ }
      }
      function sendStep(step: string, status: string, detail: string) {
        send({ type: "step", step, status, detail })
      }

      let browser = null

      try {
        // Generate random data
        const firstName = randomFrom(FIRST_NAMES)
        const lastName = randomFrom(LAST_NAMES)
        const email = generateEmail()
        const phone = generatePhone(countryCode, countryDigits)
        const password = generatePassword()

        send({
          type: "generated-data",
          data: { firstName, lastName, email, phone, password },
        })
        sendStep("Generated random data", "success",
          `Name: ${firstName} ${lastName} | Email: ${email} | Phone: ${phone} | Pass: ${password}`)

        // Step 1: Launch browser
        sendStep("Launching browser", "running", "Starting Headless Chrome...")
        browser = await puppeteer.launch({
          args: [
            ...chromium.args,
            "--disable-blink-features=AutomationControlled",  // Hide automation flag
            "--disable-features=IsolateOrigins,site-per-process",  // Help with iframe access
            "--disable-web-security",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-infobars",
          ],
          executablePath: await chromium.executablePath(),
          headless: true,
          protocolTimeout: 120000,  // Prevent CDP timeouts during long press & hold
        })
        const page = await browser.newPage()
        await page.setViewport({ width: 1280, height: 800, deviceScaleFactor: 1 })
        await page.setUserAgent(
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
        )

        // Apply stealth patches BEFORE navigation (critical for PerimeterX)
        await page.evaluateOnNewDocument(() => {
          // Hide webdriver flag
          Object.defineProperty(navigator, "webdriver", { get: () => undefined })

          // Create realistic chrome object
          const chrome = {
            app: { isInstalled: false, InstallState: { DISABLED: "disabled", INSTALLED: "installed", NOT_INSTALLED: "not_installed" }, RunningState: { CANNOT_RUN: "cannot_run", READY_TO_RUN: "ready_to_run", RUNNING: "running" } },
            runtime: { OnInstalledReason: { CHROME_UPDATE: "chrome_update", INSTALL: "install", SHARED_MODULE_UPDATE: "shared_module_update", UPDATE: "update" }, OnRestartRequiredReason: { APP_UPDATE: "app_update", OS_UPDATE: "os_update", PERIODIC: "periodic" }, PlatformArch: { ARM: "arm", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" }, PlatformNaclArch: { ARM: "arm", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" }, PlatformOs: { ANDROID: "android", CROS: "cros", LINUX: "linux", MAC: "mac", OPENBSD: "openbsd", WIN: "win" }, RequestUpdateCheckStatus: { NO_UPDATE: "no_update", THROTTLED: "throttled", UPDATE_AVAILABLE: "update_available" }, connect: () => {}, sendMessage: () => {} },
            csi: () => ({}),
            loadTimes: () => ({ commitLoadTime: Date.now() / 1000, connectionInfo: "h2", finishDocumentLoadTime: 0, finishLoadTime: 0, firstPaintAfterLoadTime: 0, firstPaintTime: 0, navigationType: "Other", npnNegotiatedProtocol: "h2", requestTime: Date.now() / 1000, startLoadTime: Date.now() / 1000, wasAlternateProtocolAvailable: false, wasFetchedViaSpdy: true, wasNpnNegotiated: true }),
          };
          (window as any).chrome = chrome

          // Realistic plugins
          Object.defineProperty(navigator, "plugins", {
            get: () => {
              const plugins = [
                { name: "Chrome PDF Plugin", description: "Portable Document Format", filename: "internal-pdf-viewer", length: 1 },
                { name: "Chrome PDF Viewer", description: "", filename: "mhjfbmdgcfjbbpaeojofohoefgiehjai", length: 1 },
                { name: "Native Client", description: "", filename: "internal-nacl-plugin", length: 2 },
              ]
              return Object.assign(plugins, { refresh: () => {}, namedItem: (n: string) => plugins.find(p => p.name === n) || null, item: (i: number) => plugins[i] || null })
            }
          })

          // Languages
          Object.defineProperty(navigator, "languages", { get: () => ["en-US", "en"] })
          Object.defineProperty(navigator, "language", { get: () => "en-US" })

          // Permissions
          const origQuery = window.navigator.permissions?.query?.bind(window.navigator.permissions)
          if (origQuery) {
            (window.navigator.permissions as any).query = (params: any) =>
              params.name === "notifications"
                ? Promise.resolve({ state: Notification.permission } as PermissionStatus)
                : origQuery(params)
          }

          // WebGL vendor/renderer (avoid "Google SwiftShader" which screams headless)
          const getParameter = WebGLRenderingContext.prototype.getParameter
          WebGLRenderingContext.prototype.getParameter = function(param: number) {
            if (param === 37445) return "Intel Inc."
            if (param === 37446) return "Intel Iris OpenGL Engine"
            return getParameter.call(this, param)
          }

          // Connection info
          Object.defineProperty(navigator, "connection", {
            get: () => ({ downlink: 10, effectiveType: "4g", rtt: 50, saveData: false }),
          })

          // Hardware concurrency
          Object.defineProperty(navigator, "hardwareConcurrency", { get: () => 8 })

          // Device memory
          Object.defineProperty(navigator, "deviceMemory", { get: () => 8 })
        })

        sendStep("Launching browser", "success", "Headless Chrome started with stealth patches")

        // Step 2: Navigate
        sendStep("Navigating to page", "running", `Loading ${url}...`)
        try {
          await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 })
          sendStep("Navigating to page", "success", `Loaded: ${page.url()}`)
        } catch {
          sendStep("Navigating to page", "failed", "Could not load the page.")
          send({ type: "done", success: false, error: "Failed to load page." })
          await browser.close()
          controller.close()
          return
        }

        await new Promise((r) => setTimeout(r, 2000))

        // Step 3-7: Fill form fields using label-based detection
        sendStep("Filling form fields", "running", "Detecting and filling all inputs...")

        const fillResults = await page.evaluate((data: { firstName: string, lastName: string, email: string, phone: string, password: string }) => {
          const results: Record<string, { found: boolean, method: string }> = {}
          function findInputByLabel(labelTexts: string[]): HTMLInputElement | null {
            const allLabels = Array.from(document.querySelectorAll("label"))
            for (const lbl of allLabels) {
              const text = (lbl.innerText || lbl.textContent || "").toLowerCase().trim()
              if (labelTexts.some(t => text.includes(t))) {
                const forAttr = lbl.getAttribute("for")
                if (forAttr) { const input = document.getElementById(forAttr) as HTMLInputElement; if (input) return input }
                const inner = lbl.querySelector("input") as HTMLInputElement; if (inner) return inner
                const next = lbl.nextElementSibling; if (next && next.tagName === "INPUT") return next as HTMLInputElement
                const parent = lbl.parentElement; if (parent) { const inp = parent.querySelector("input") as HTMLInputElement; if (inp) return inp }
              }
            }
            const allTexts = Array.from(document.querySelectorAll("span, p, div, h1, h2, h3, h4, h5, h6, strong, b, td, th"))
            for (const el of allTexts) {
              const text = (el.innerText || el.textContent || "").toLowerCase().trim()
              if (text.length > 50) continue
              if (labelTexts.some(t => text.includes(t))) {
                const parent = el.parentElement
                if (parent) {
                  const inp = parent.querySelector("input") as HTMLInputElement; if (inp) return inp
                  const next = el.nextElementSibling
                  if (next) { const nestInp = next.querySelector ? (next.querySelector("input") as HTMLInputElement) : null; if (nestInp) return nestInp; if (next.tagName === "INPUT") return next as HTMLInputElement }
                }
              }
            }
            return null
          }
          function setVal(input: HTMLInputElement, value: string): boolean {
            input.focus()
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set
            if (nativeSetter) nativeSetter.call(input, value); else input.value = value
            input.dispatchEvent(new Event("input", { bubbles: true }))
            input.dispatchEvent(new Event("change", { bubbles: true }))
            input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }))
            input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }))
            return true
          }
          let inp = findInputByLabel(["first name", "first_name", "firstname", "given name", "nombre"])
          if (!inp) inp = document.querySelector('input[name*="first" i], input[id*="first" i], input[placeholder*="first" i], input[name*="fname" i], input[autocomplete="given-name"]') as HTMLInputElement
          if (inp) { setVal(inp, data.firstName); results.firstName = { found: true, method: "label/attr" } } else results.firstName = { found: false, method: "not found" }
          inp = findInputByLabel(["last name", "last_name", "lastname", "family name", "surname", "apellido"])
          if (!inp) inp = document.querySelector('input[name*="last" i], input[id*="last" i], input[placeholder*="last" i], input[name*="lname" i], input[autocomplete="family-name"]') as HTMLInputElement
          if (inp) { setVal(inp, data.lastName); results.lastName = { found: true, method: "label/attr" } } else results.lastName = { found: false, method: "not found" }
          inp = findInputByLabel(["email", "e-mail", "correo"])
          if (!inp) inp = document.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i], input[placeholder*="email" i], input[autocomplete="email"]') as HTMLInputElement
          if (inp) { setVal(inp, data.email); results.email = { found: true, method: "label/attr" } } else results.email = { found: false, method: "not found" }
          inp = findInputByLabel(["phone", "mobile", "tel", "number", "telefono", "celular"])
          if (!inp) inp = document.querySelector('input[type="tel"], input[name*="phone" i], input[id*="phone" i], input[placeholder*="phone" i], input[name*="mobile" i], input[autocomplete="tel"]') as HTMLInputElement
          if (inp) { setVal(inp, data.phone); results.phone = { found: true, method: "label/attr" } } else results.phone = { found: false, method: "not found" }
          const passFields = Array.from(document.querySelectorAll('input[type="password"]')) as HTMLInputElement[]
          if (passFields.length >= 2) {
            setVal(passFields[0], data.password); setVal(passFields[1], data.password)
            results.password = { found: true, method: "2 password fields" }; results.confirmPassword = { found: true, method: "2nd password field" }
          } else if (passFields.length === 1) {
            setVal(passFields[0], data.password); results.password = { found: true, method: "1 password field" }
            const confirmInp = findInputByLabel(["confirm password", "confirm_password", "re-enter", "retype", "password again"])
            if (confirmInp) { setVal(confirmInp, data.password); results.confirmPassword = { found: true, method: "label" } }
            else results.confirmPassword = { found: false, method: "no confirm field" }
          } else { results.password = { found: false, method: "no password fields" }; results.confirmPassword = { found: false, method: "no password fields" } }
          return results
        }, { firstName, lastName, email, phone, password })

        // Re-type via Puppeteer keyboard for better compatibility
        for (const [, labelTexts, value] of [
          ["First Name", ["first"], firstName],
          ["Last Name", ["last"], lastName],
          ["Email", ["email"], email],
          ["Phone", ["phone", "tel", "mobile"], phone],
        ] as [string, string[], string][]) {
          for (const term of labelTexts) {
            const el = await page.$(`input[name*="${term}" i]`) || await page.$(`input[id*="${term}" i]`) || await page.$(`input[placeholder*="${term}" i]`)
            if (el) { await el.click({ clickCount: 3 }); await el.type(value, { delay: 20 }); break }
          }
        }

        // Send each field result as a live step
        sendStep("Filling First Name", fillResults.firstName?.found ? "success" : "failed", fillResults.firstName?.found ? `Typed: ${firstName}` : "Field not found")
        sendStep("Filling Last Name", fillResults.lastName?.found ? "success" : "failed", fillResults.lastName?.found ? `Typed: ${lastName}` : "Field not found")
        sendStep("Filling Email", fillResults.email?.found ? "success" : "failed", fillResults.email?.found ? `Typed: ${email}` : "Field not found")
        sendStep("Filling Phone", fillResults.phone?.found ? "success" : "failed", fillResults.phone?.found ? `Typed: ${phone}` : "Field not found")
        sendStep("Filling Password", fillResults.password?.found ? "success" : "failed", fillResults.password?.found ? `Password: ${password}` : "No password field")
        sendStep("Confirm Password", fillResults.confirmPassword?.found ? "success" : "failed", fillResults.confirmPassword?.found ? "Confirm password entered" : "No confirm field")

        await new Promise((r) => setTimeout(r, 500))

        // ========== STEP 8: MULTI-FALLBACK CAPTCHA SOLVER WITH RETRY ==========
        // Order: Saturation E2 (8 retries) -> 11 more OCR variants -> AI Vision (last)
        // Each solver: 30s timeout, up to 3 attempts if wrong captcha detected
        sendStep("Detecting captcha", "running", "Looking for captcha image on page...")

        // Helper: find captcha image element
        async function findCaptchaImg() {
          return await page.$('img[src*="captcha" i]') ||
            await page.$('img[class*="captcha" i]') || await page.$('img[id*="captcha" i]') ||
            await page.$('img[alt*="captcha" i]') || await page.$('[class*="captcha" i] img') ||
            await page.$('[id*="captcha" i] img') || await page.$('canvas[class*="captcha" i]') ||
            await page.$('canvas[id*="captcha" i]')
        }

        // Helper: screenshot captcha and return base64
        async function screenshotCaptcha() {
          const el = await findCaptchaImg()
          if (!el) return null
          const ss = await el.screenshot({ encoding: "base64", type: "png" })
          return typeof ss === "string" ? ss : Buffer.from(ss).toString("base64")
        }

        // ===== KNOWN SELECTORS from Walmart RetailLink registration page =====
        // Captcha input: <input type="text" class="form-control__formControl___3uDUX" data-automation-id="">
        // Tick button:   <img class="validate-btn" src="//i5.walmartimages.com/...">
        // The class hash (3uDUX) may change, so we use partial match: [class*="formControl"]

        // Helper: Get the EXACT captcha input element using Puppeteer
        async function getCaptchaInputHandle() {
          // Strategy 1: Find img.validate-btn, then find the sibling input next to it
          // The validate-btn is the tick, the input is directly to its left in the same row
          let handle = await page.evaluateHandle(() => {
            const tick = document.querySelector('img.validate-btn')
            if (tick) {
              // The input should be the previous sibling or in a sibling container
              const parent = tick.parentElement
              if (parent) {
                const inp = parent.querySelector('input[type="text"]') || parent.previousElementSibling?.querySelector('input[type="text"]')
                if (inp) return inp
                // Try parent's parent
                const grandParent = parent.parentElement
                if (grandParent) {
                  const inp2 = grandParent.querySelector('input[type="text"]')
                  if (inp2) return inp2
                }
              }
            }
            return null
          })
          let el = handle.asElement()
          if (el) return el

          // Strategy 2: Direct selector for the known class pattern
          el = await page.$('input[class*="formControl"]')
          if (el) {
            // Verify this is the captcha one (not another form field) by checking it's near the captcha image
            const isNearCaptcha = await page.evaluate((inp: Element) => {
              const captchaImg = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
              if (!captchaImg) return false
              const imgRect = captchaImg.getBoundingClientRect()
              const inpRect = inp.getBoundingClientRect()
              const dy = inpRect.y - (imgRect.y + imgRect.height)
              const dx = Math.abs((inpRect.x + inpRect.width / 2) - (imgRect.x + imgRect.width / 2))
              return dy >= -20 && dy < 200 && dx < 300
            }, el)
            if (isNearCaptcha) return el
          }

          // Strategy 3: Find ALL inputs with formControl class, pick the one closest to captcha image
          const allFormControlInputs = await page.$$('input[class*="formControl"]')
          if (allFormControlInputs.length > 0) {
            for (const inp of allFormControlInputs) {
              const isNear = await page.evaluate((el: Element) => {
                const captchaImg = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
                if (!captchaImg) return false
                const imgRect = captchaImg.getBoundingClientRect()
                const inpRect = el.getBoundingClientRect()
                const dy = inpRect.y - (imgRect.y + imgRect.height)
                const dx = Math.abs((inpRect.x + inpRect.width / 2) - (imgRect.x + imgRect.width / 2))
                return dy >= -20 && dy < 200 && dx < 300
              }, inp)
              if (isNear) return inp
            }
          }

          // Strategy 4: Find by data-automation-id attribute (empty but exists)
          const dataAutoInputs = await page.$$('input[data-automation-id]')
          for (const inp of dataAutoInputs) {
            const info = await page.evaluate((el: Element) => {
              const inputEl = el as HTMLInputElement
              if (inputEl.type === "password" || inputEl.type === "hidden" || inputEl.type === "email") return null
              const captchaImg = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
              if (!captchaImg) return null
              const imgRect = captchaImg.getBoundingClientRect()
              const inpRect = el.getBoundingClientRect()
              const dy = inpRect.y - (imgRect.y + imgRect.height)
              return dy >= -20 && dy < 200 ? "near" : null
            }, inp)
            if (info) return inp
          }

          // Strategy 5: Spatial proximity (fallback) - find the text input BELOW captcha image
          handle = await page.evaluateHandle(() => {
            const captchaImg = document.querySelector('img[src*="captcha" i]') ||
              document.querySelector('img[class*="captcha" i]') || document.querySelector('[class*="captcha" i] img')
            if (!captchaImg) return null
            const imgRect = captchaImg.getBoundingClientRect()

            const allInputs = Array.from(document.querySelectorAll('input')) as HTMLInputElement[]
            let best: HTMLInputElement | null = null
            let bestScore = Infinity
            for (const inp of allInputs) {
              const type = (inp.type || "text").toLowerCase()
              if (["password", "email", "tel", "hidden", "checkbox", "radio", "submit", "button", "file"].includes(type)) continue
              const r = inp.getBoundingClientRect()
              if (r.width < 15 || r.top < 0) continue
              const dy = r.y - (imgRect.y + imgRect.height)
              const dx = Math.abs((r.x + r.width / 2) - (imgRect.x + imgRect.width / 2))
              if (dy < -20 || dy > 200 || dx > 300) continue
              const score = dy * 2 + dx
              if (score < bestScore) { bestScore = score; best = inp }
            }
            return best
          })
          el = handle.asElement()
          return el || null
        }

        // Helper: type answer into captcha input using MULTIPLE methods with verification
        async function typeCaptchaAnswer(answer: string) {
          // First scroll to make captcha area visible
          await page.evaluate(() => {
            const captchaImg = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
            if (captchaImg) captchaImg.scrollIntoView({ behavior: "smooth", block: "center" })
          })
          await new Promise(r => setTimeout(r, 500))

          const inputEl = await getCaptchaInputHandle()
          if (!inputEl) {
            sendStep("Captcha input", "failed", "Could not find captcha input with any of 5 strategies!")
            return false
          }

          // Log what we found
          const inputInfo = await page.evaluate((el: Element) => {
            const r = el.getBoundingClientRect()
            const inp = el as HTMLInputElement
            return `Found input: class="${inp.className?.substring(0, 40)}" pos=(${Math.round(r.x)},${Math.round(r.y)}) ${Math.round(r.width)}x${Math.round(r.height)}`
          }, inputEl)
          sendStep("Captcha input", "success", inputInfo)

          // Method 1: Puppeteer element click + type (most reliable for real Puppeteer elements)
          try {
            await inputEl.click({ clickCount: 3 })
            await new Promise(r => setTimeout(r, 200))
            await page.keyboard.down("Control"); await page.keyboard.press("a"); await page.keyboard.up("Control")
            await page.keyboard.press("Backspace")
            await new Promise(r => setTimeout(r, 100))
            await inputEl.type(answer, { delay: 70 })
            await new Promise(r => setTimeout(r, 300))
          } catch (e) {
            sendStep("Captcha type M1", "failed", `Click+type failed: ${e instanceof Error ? e.message : "unknown"}`)
          }

          // Verify
          const v1 = await page.evaluate((el: Element, expected: string) => {
            return (el as HTMLInputElement).value === expected
          }, inputEl, answer)
          if (v1) {
            sendStep("Captcha typed", "success", `Method 1 (element click+type): "${answer}"`)
            return true
          }

          // Method 2: Focus + keyboard type
          sendStep("Captcha type M1", "failed", "Value not confirmed, trying focus+type...")
          try {
            await page.evaluate((el: Element) => { (el as HTMLInputElement).value = ""; (el as HTMLInputElement).focus() }, inputEl)
            await new Promise(r => setTimeout(r, 200))
            await page.keyboard.type(answer, { delay: 70 })
            await new Promise(r => setTimeout(r, 300))
          } catch {}
          const v2 = await page.evaluate((el: Element, expected: string) => (el as HTMLInputElement).value === expected, inputEl, answer)
          if (v2) {
            sendStep("Captcha typed", "success", `Method 2 (focus+keyboard): "${answer}"`)
            return true
          }

          // Method 3: React value setter
          sendStep("Captcha type M2", "failed", "Trying React setter...")
          const v3 = await page.evaluate((el: Element, ans: string) => {
            const inp = el as HTMLInputElement
            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set
            if (setter) {
              setter.call(inp, ans)
              inp.dispatchEvent(new Event("input", { bubbles: true }))
              inp.dispatchEvent(new Event("change", { bubbles: true }))
              return inp.value === ans
            }
            return false
          }, inputEl, answer)
          if (v3) {
            sendStep("Captcha typed", "success", `Method 3 (React setter): "${answer}"`)
            return true
          }

          // Method 4: Coordinate click + keyboard
          sendStep("Captcha type M3", "failed", "Trying coordinate click...")
          const coords = await page.evaluate((el: Element) => {
            const r = el.getBoundingClientRect()
            return { x: r.x + r.width / 2, y: r.y + r.height / 2 }
          }, inputEl)
          await page.mouse.click(coords.x, coords.y, { clickCount: 3 })
          await new Promise(r => setTimeout(r, 200))
          await page.keyboard.down("Control"); await page.keyboard.press("a"); await page.keyboard.up("Control")
          await page.keyboard.press("Backspace")
          await page.keyboard.type(answer, { delay: 70 })
          await new Promise(r => setTimeout(r, 300))
          const v4 = await page.evaluate((el: Element, expected: string) => (el as HTMLInputElement).value === expected, inputEl, answer)
          if (v4) {
            sendStep("Captcha typed", "success", `Method 4 (coord click): "${answer}"`)
            return true
          }

          // Method 5: Tab from password field
          sendStep("Captcha type M4", "failed", "Trying Tab from password...")
          const passField = await page.$('input[type="password"]:last-of-type') || await page.$('input[type="password"]')
          if (passField) {
            await passField.click()
            await new Promise(r => setTimeout(r, 200))
            for (let t = 0; t < 8; t++) {
              await page.keyboard.press("Tab")
              await new Promise(r => setTimeout(r, 150))
              const isCaptchaInput = await page.evaluate((el: Element) => document.activeElement === el, inputEl)
              if (isCaptchaInput) {
                await page.keyboard.down("Control"); await page.keyboard.press("a"); await page.keyboard.up("Control")
                await page.keyboard.press("Backspace")
                await page.keyboard.type(answer, { delay: 70 })
                const v5 = await page.evaluate((el: Element, expected: string) => (el as HTMLInputElement).value === expected, inputEl, answer)
                if (v5) {
                  sendStep("Captcha typed", "success", `Method 5 (Tab x${t + 1}): "${answer}"`)
                  return true
                }
                break
              }
            }
          }

          sendStep("Captcha typed", "failed", "All 5 methods failed!")
          return false
        }

        // Helper: click the validate-btn tick image
        async function clickCaptchaTick() {
          // Strategy 1: Direct selector (KNOWN: img.validate-btn)
          const tickImg = await page.$('img.validate-btn')
          if (tickImg) {
            await tickImg.click()
            sendStep("Tick click", "success", "Clicked img.validate-btn directly")
            return true
          }

          // Strategy 2: Find image with "validate" in class/src near captcha
          const fallbackTick = await page.$('img[class*="validate" i]') || await page.$('img[src*="validate" i]')
          if (fallbackTick) {
            await fallbackTick.click()
            sendStep("Tick click", "success", "Clicked validate image (fallback)")
            return true
          }

          // Strategy 3: Find small clickable element to the right of captcha input
          const inputEl = await getCaptchaInputHandle()
          if (inputEl) {
            const tickCoords = await page.evaluate((inp: Element) => {
              const inputRect = inp.getBoundingClientRect()
              const allImgs = Array.from(document.querySelectorAll('img'))
              for (const img of allImgs) {
                const r = img.getBoundingClientRect()
                const style = window.getComputedStyle(img)
                if (style.cursor !== "pointer") continue
                const vDist = Math.abs((r.y + r.height / 2) - (inputRect.y + inputRect.height / 2))
                const hGap = r.x - (inputRect.x + inputRect.width)
                if (vDist < 40 && hGap > -10 && hGap < 150) {
                  return { x: r.x + r.width / 2, y: r.y + r.height / 2 }
                }
              }
              return null
            }, inputEl)
            if (tickCoords) {
              await page.mouse.click(tickCoords.x, tickCoords.y)
              sendStep("Tick click", "success", `Clicked at (${tickCoords.x},${tickCoords.y}) via proximity`)
              return true
            }
          }

          sendStep("Tick click", "failed", "Could not find tick button")
          return false
        }

        // Helper: check if page shows "wrong captcha" error after clicking tick
        async function isCaptchaWrong(): Promise<boolean> {
          await new Promise(r => setTimeout(r, 1500))
          return await page.evaluate(() => {
            const text = (document.body.innerText || "").toLowerCase()
            return text.includes("wrong captcha") || text.includes("invalid captcha") ||
              text.includes("incorrect captcha") || text.includes("captcha error") ||
              text.includes("captcha mismatch") || text.includes("captcha failed") ||
              text.includes("try again") || text.includes("verification failed") ||
              text.includes("code is incorrect") || text.includes("invalid code") ||
              text.includes("wrong code") || text.includes("incorrect code")
          })
        }

        // Helper: click refresh/reload captcha button
        // KNOWN: The refresh button is a small <img> (18x18px) near the TOP-RIGHT of the captcha image
        // It's an SVG from i5.walmartimages.com with cursor:pointer
        async function refreshCaptcha() {
          const refreshed = await page.evaluate(() => {
            // Find the captcha image first
            const captchaImg = document.querySelector('img[src*="captcha" i]') ||
              document.querySelector('img[class*="captcha" i]') || document.querySelector('[class*="captcha" i] img') ||
              document.querySelector('img[id*="captcha" i]')
            if (!captchaImg) return false
            const imgRect = captchaImg.getBoundingClientRect()

            // Strategy 1: Find small <img> elements near the top-right of the captcha image
            // The refresh icon is 18x18px, cursor:pointer, positioned at top-right of captcha area
            const allImgs = Array.from(document.querySelectorAll('img'))
            for (const img of allImgs) {
              if (img === captchaImg) continue
              const r = img.getBoundingClientRect()
              // Must be small (icon-sized: < 40px)
              if (r.width > 40 || r.height > 40 || r.width < 5 || r.height < 5) continue
              const style = window.getComputedStyle(img)
              if (style.cursor !== "pointer") continue
              // Must be near the top-right of the captcha image (within ~50px)
              const nearTopRight = (
                r.x >= imgRect.x + imgRect.width * 0.5 && // right half
                r.y <= imgRect.y + imgRect.height * 0.5 && // top half
                r.x <= imgRect.x + imgRect.width + 60 &&   // not too far right
                r.y >= imgRect.y - 40                        // not too far above
              )
              if (nearTopRight) { img.click(); return true }
            }

            // Strategy 2: Find ANY small clickable img/svg/i near the captcha that isn't the validate-btn
            const allClickable = Array.from(document.querySelectorAll('img, svg, i, a, button, [role="button"]'))
            for (const el of allClickable) {
              const htmlEl = el as HTMLElement
              if (htmlEl.classList.contains("validate-btn")) continue // skip the tick button
              if (htmlEl === captchaImg) continue
              const r = htmlEl.getBoundingClientRect()
              if (r.width > 40 || r.height > 40 || r.width < 5 || r.height < 5) continue
              const style = window.getComputedStyle(htmlEl)
              if (style.cursor !== "pointer") continue
              // Near the captcha image area
              const nearCaptcha = (
                Math.abs(r.y - imgRect.y) < 50 && // near top of captcha
                r.x >= imgRect.x - 20 &&
                r.x <= imgRect.x + imgRect.width + 60
              )
              if (nearCaptcha) { htmlEl.click(); return true }
            }

            // Strategy 3: Look inside captcha container for refresh-like elements
            const container = document.querySelector('[class*="captcha" i]') || document.querySelector('[id*="captcha" i]')
            if (container) {
              const btns = container.querySelectorAll('a, button, [role="button"], img, svg, i')
              for (const el of Array.from(btns)) {
                const cls = ((el as HTMLElement).className || "").toLowerCase()
                const aria = ((el as HTMLElement).getAttribute("aria-label") || "").toLowerCase()
                const title = ((el as HTMLElement).getAttribute("title") || "").toLowerCase()
                if (cls.includes("refresh") || cls.includes("reload") || cls.includes("retry") ||
                  aria.includes("refresh") || aria.includes("reload") ||
                  title.includes("refresh") || title.includes("reload")) {
                  (el as HTMLElement).click(); return true
                }
              }
            }

            return false
          })

          if (refreshed) {
            await new Promise(r => setTimeout(r, 2500)) // wait for new captcha image to load
          }
          return refreshed
        }

        // Helper: run a solver with 30s timeout
        function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
          return Promise.race([
            promise,
            new Promise<T>((_, reject) => setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)),
          ])
        }

        // ----- Image preprocessing helper (runs in browser) -----
        async function preprocessImage(b64: string, mode: string): Promise<string> {
          return await page.evaluate((imgB64: string, preprocessMode: string) => {
            return new Promise<string>((resolve) => {
              const img = new Image(); img.crossOrigin = "anonymous"
              img.onload = () => {
                const scale = 4
                const canvas = document.createElement("canvas")
                canvas.width = img.width * scale; canvas.height = img.height * scale
                const ctx = canvas.getContext("2d")!
                ctx.fillStyle = "#FFFFFF"
                ctx.fillRect(0, 0, canvas.width, canvas.height)
                ctx.imageSmoothingEnabled = false
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
                const d = imageData.data

                if (preprocessMode === "saturation") {
                  // Keep only saturated (colored) pixels = the letters
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
                    const sat = mx === 0 ? 0 : (mx - mn) / mx
                    const bri = (r + g + b) / 3
                    if (sat > 0.25 && bri < 200) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "dark") {
                  // Keep only dark pixels
                  for (let i = 0; i < d.length; i += 4) {
                    const bri = (d[i] + d[i+1] + d[i+2]) / 3
                    const v = bri < 100 ? 0 : 255
                    d[i] = v; d[i+1] = v; d[i+2] = v
                  }
                } else if (preprocessMode === "aggressive") {
                  // Aggressive: anything not very light is black
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
                    const sat = mx === 0 ? 0 : (mx - mn) / mx
                    const bri = (r + g + b) / 3
                    if (bri < 160 || (sat > 0.2 && bri < 210)) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "red_channel") {
                  // Isolate red channel
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const isReddish = r > 80 && r > g * 1.3 && r > b * 1.3
                    if (isReddish) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "green_channel") {
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const isGreenish = g > 60 && g > r * 1.2 && g > b * 1.1
                    if (isGreenish) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "blue_channel") {
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const isBluish = b > 60 && b > r * 1.1 && b > g * 1.1
                    if (isBluish) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "combined_color") {
                  // Keep any significantly colored pixel (high saturation OR dark)
                  for (let i = 0; i < d.length; i += 4) {
                    const r = d[i], g = d[i+1], b = d[i+2]
                    const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
                    const sat = mx === 0 ? 0 : (mx - mn) / mx
                    const bri = (r + g + b) / 3
                    if (bri < 80 || sat > 0.35 || (sat > 0.15 && bri < 150)) { d[i] = 0; d[i+1] = 0; d[i+2] = 0 }
                    else { d[i] = 255; d[i+1] = 255; d[i+2] = 255 }
                  }
                } else if (preprocessMode === "grayscale_tight") {
                  for (let i = 0; i < d.length; i += 4) {
                    const gray = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]
                    const v = gray < 130 ? 0 : 255
                    d[i] = v; d[i+1] = v; d[i+2] = v
                  }
                } else if (preprocessMode === "grayscale_loose") {
                  for (let i = 0; i < d.length; i += 4) {
                    const gray = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]
                    const v = gray < 170 ? 0 : 255
                    d[i] = v; d[i+1] = v; d[i+2] = v
                  }
                } else {
                  // raw: just upscale, no filter
                }

                ctx.putImageData(imageData, 0, 0)
                resolve(canvas.toDataURL("image/png").split(",")[1])
              }
              img.src = "data:image/png;base64," + imgB64
            })
          }, b64, mode)
        }

        // ----- 2Captcha API solver (PRIMARY - paid, most reliable) -----
        const CAPTCHA_API_KEY = process.env.CAPTCHA_API_KEY || ""

        async function solve2Captcha(b64: string): Promise<string | null> {
          if (!CAPTCHA_API_KEY) return null

          // Step 1: Submit captcha image
          const submitForm = new URLSearchParams()
          submitForm.append("key", CAPTCHA_API_KEY)
          submitForm.append("method", "base64")
          submitForm.append("body", b64)
          submitForm.append("json", "1")
          // Tell 2captcha it's a normal text captcha, case-sensitive, 3-6 chars
          submitForm.append("numeric", "0")       // 0 = any characters
          submitForm.append("min_len", "3")
          submitForm.append("max_len", "8")
          submitForm.append("language", "2")       // 2 = English
          submitForm.append("case", "1")           // 1 = case-sensitive

          const submitRes = await fetch("https://2captcha.com/in.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: submitForm.toString(),
          })
          const submitData = await submitRes.json()
          if (submitData.status !== 1 || !submitData.request) {
            throw new Error(`2Captcha submit error: ${submitData.request || "unknown"}`)
          }

          const taskId = submitData.request

          // Step 2: Poll for result (2captcha usually takes 5-15 seconds for image captchas)
          for (let poll = 0; poll < 20; poll++) {
            await new Promise(r => setTimeout(r, 3000)) // Wait 3 seconds between polls

            const resultRes = await fetch(
              `https://2captcha.com/res.php?key=${CAPTCHA_API_KEY}&action=get&id=${taskId}&json=1`
            )
            const resultData = await resultRes.json()

            if (resultData.status === 1 && resultData.request) {
              // Got answer!
              const cleaned = resultData.request.trim().replace(/[^a-zA-Z0-9]/g, "")
              if (cleaned && cleaned.length >= 3 && cleaned.length <= 10) return cleaned
              return resultData.request.trim() // Return raw if cleaning removed too much
            }

            if (resultData.request === "CAPCHA_NOT_READY") continue // Still processing

            // Error
            throw new Error(`2Captcha result error: ${resultData.request || "unknown"}`)
          }

          return null // Timed out after 60 seconds of polling
        }

        // ----- OCR.space caller helper (FALLBACK - free) -----
        async function callOcrSpace(b64: string, engine: string): Promise<string | null> {
          const formData = new URLSearchParams()
          formData.append("apikey", "helloworld")
          formData.append("base64Image", `data:image/png;base64,${b64}`)
          formData.append("language", "eng")
          formData.append("isOverlayRequired", "false")
          formData.append("scale", "true")
          formData.append("OCREngine", engine)
          const res = await fetch("https://api.ocr.space/parse/image", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: formData.toString(),
          })
          const data = await res.json()
          if (data.ParsedResults?.[0]) {
            const raw = data.ParsedResults[0].ParsedText || ""
            const cleaned = raw.trim().replace(/[^a-zA-Z0-9]/g, "")
            if (cleaned && cleaned.length >= 3 && cleaned.length <= 10) return cleaned
          }
          return null
        }

        // ----- All solver functions -----
        // 1. Raw image -> OCR.space Engine 2
        async function solver_rawE2(b64: string) { return callOcrSpace(b64, "2") }

        // 2. Saturation filter -> OCR.space Engine 2
        async function solver_satE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "saturation"), "2") }

        // 3. Combined color filter -> OCR.space Engine 2
        async function solver_combinedE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "combined_color"), "2") }

        // 4. Aggressive filter -> OCR.space Engine 1
        async function solver_aggressiveE1(b64: string) { return callOcrSpace(await preprocessImage(b64, "aggressive"), "1") }

        // 5. Dark pixels -> OCR.space Engine 2
        async function solver_darkE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "dark"), "2") }

        // 6. Grayscale tight -> OCR.space Engine 1
        async function solver_grayTightE1(b64: string) { return callOcrSpace(await preprocessImage(b64, "grayscale_tight"), "1") }

        // 7. Grayscale loose -> OCR.space Engine 2
        async function solver_grayLooseE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "grayscale_loose"), "2") }

        // 8. Red channel isolated -> OCR.space Engine 2
        async function solver_redE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "red_channel"), "2") }

        // 9. Green channel -> OCR.space Engine 2
        async function solver_greenE2(b64: string) { return callOcrSpace(await preprocessImage(b64, "green_channel"), "2") }

        // 10. Blue channel -> OCR.space Engine 1
        async function solver_blueE1(b64: string) { return callOcrSpace(await preprocessImage(b64, "blue_channel"), "1") }

        // 11. Saturation filter -> OCR.space Engine 1 (different engine)
        async function solver_satE1(b64: string) { return callOcrSpace(await preprocessImage(b64, "saturation"), "1") }

        // 12. Raw image -> OCR.space Engine 1
        async function solver_rawE1(b64: string) { return callOcrSpace(b64, "1") }

        // ----- Main captcha solving loop (2Captcha only) -----
        let captchaAnswer = ""
        let captchaSolved = false
        const captchaEl = await findCaptchaImg()

        if (captchaEl) {
          sendStep("Detecting captcha", "success", "Captcha image found! Sending to 2Captcha...")

          // Helper: check if captcha is validated on the page
          async function isCaptchaValidated(): Promise<boolean> {
            return page.evaluate(() => {
              const text = (document.body.innerText || "").toLowerCase()
              if (text.includes("captcha validated") || text.includes("captcha verified")) return true
              const img = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
              if (!img) return true
              const inp = document.querySelector('input[class*="formControl"]')
              if (!inp) return true
              return false
            })
          }

          // Helper: check validation result after typing + clicking verify
          async function checkValidationResult(): Promise<"validated" | "wrong" | "unknown"> {
            for (let w = 0; w < 4; w++) {
              await new Promise(r => setTimeout(r, 1000))
              const result = await page.evaluate(() => {
                const text = (document.body.innerText || "").toLowerCase()
                if (text.includes("captcha validated") || text.includes("captcha verified")) return "validated"
                const img = document.querySelector('img[src*="captcha" i]') || document.querySelector('img[class*="captcha" i]')
                if (!img) return "validated"
                const inp = document.querySelector('input[class*="formControl"]')
                if (!inp) return "validated"
                if (text.includes("wrong captcha") || text.includes("invalid captcha") ||
                    text.includes("incorrect captcha") || text.includes("captcha error") ||
                    text.includes("verification failed") || text.includes("code is incorrect") ||
                    text.includes("wrong code") || text.includes("incorrect code")) return "wrong"
                if ((inp as HTMLInputElement).value.trim() === "") return "wrong"
                return "unknown"
              })
              if (result !== "unknown") return result as "validated" | "wrong" | "unknown"
            }
            return "unknown"
          }

          // Run up to 6 rounds with 2Captcha only
          const MAX_ROUNDS = 6
          for (let round = 1; round <= MAX_ROUNDS && !captchaSolved; round++) {
            if (round > 1) {
              sendStep("Captcha refresh", "running", `Refreshing captcha (round ${round})...`)
              await refreshCaptcha()
              await new Promise(r => setTimeout(r, 500))
            }

            if (await isCaptchaValidated()) {
              captchaSolved = true
              sendStep("Captcha solved!", "success", "Already validated!")
              break
            }

            const b64 = await screenshotCaptcha()
            if (!b64) {
              sendStep("Captcha", "failed", `Could not capture captcha (round ${round}/${MAX_ROUNDS})`)
              continue
            }

            sendStep("2Captcha", "running", `Round ${round}/${MAX_ROUNDS}: Submitting to 2Captcha...`)

            try {
              const answer = await withTimeout(solve2Captcha(b64), 60000, "2Captcha")
              if (!answer) {
                sendStep("2Captcha", "failed", `Round ${round}: No answer returned`)
                continue
              }

              sendStep("2Captcha", "success", `Answer: "${answer}"`)

              // Type the answer
              const typed = await typeCaptchaAnswer(answer)
              if (!typed) { sendStep("Typing captcha", "failed", "Could not type into input"); continue }
              sendStep("Typing captcha", "success", `Typed: "${answer}"`)

              // Click tick/verify
              const ticked = await clickCaptchaTick()
              sendStep("Verifying captcha", ticked ? "success" : "failed", ticked ? "Clicked verify" : "No tick button")

              // Check validation
              const validation = await checkValidationResult()

              if (validation === "validated") {
                captchaAnswer = answer
                captchaSolved = true
                sendStep("Captcha solved!", "success", `"${answer}" validated! (round ${round})`)
              } else if (validation === "wrong") {
                sendStep("2Captcha", "failed", `"${answer}" rejected (round ${round})`)
                await refreshCaptcha()
              } else {
                captchaAnswer = answer
                captchaSolved = true
                sendStep("Captcha accepted", "success", `"${answer}" (no error detected) round ${round}`)
              }
            } catch (e) {
              sendStep("2Captcha", "failed", `Round ${round}: ${e instanceof Error ? e.message.substring(0, 100) : "error"}`)
            }
          }

          if (!captchaSolved) {
            sendStep("Captcha", "failed", `All ${MAX_ROUNDS} rounds failed. Captcha unsolved.`)
          }
        } else {
          const mathResult = await page.evaluate(() => {
            const text = document.body.innerText || ""
            const m = text.match(/(\d+)\s*\+\s*(\d+)\s*=\s*\?/) || text.match(/what\s+is\s+(\d+)\s*\+\s*(\d+)/i)
            if (m) return String(parseInt(m[1]) + parseInt(m[2]))
            const s = text.match(/(\d+)\s*-\s*(\d+)\s*=\s*\?/)
            if (s) return String(parseInt(s[1]) - parseInt(s[2]))
            return null
          })
          if (mathResult) { captchaAnswer = mathResult; sendStep("Math captcha", "success", `Answer: ${mathResult}`) }
          else { sendStep("Captcha detection", "success", "No captcha found (proceeding)") }
        }

        await new Promise((r) => setTimeout(r, 1000))

        // ========== SMART PAGE SCANNER ==========
        // Scan what challenges are on the page and handle them sequentially
        sendStep("Scanning page", "running", "Checking what challenges are visible...")

        async function scanPageState() {
          return await page.evaluate(() => {
            const text = (document.body.innerText || "").toLowerCase()
            const hasCaptchaImage = !!(document.querySelector('img[src*="captcha" i]') ||
              document.querySelector('img[class*="captcha" i]') || document.querySelector('[class*="captcha" i] img'))
            const hasCaptchaValidated = text.includes("captcha validated") || text.includes("captcha verified")
            const hasPressHold = text.includes("press & hold") || text.includes("press and hold")
            const hasCreateAccount = text.includes("create account")
            return { hasCaptchaImage, hasCaptchaValidated, hasPressHold, hasCreateAccount }
          })
        }

        const pageState = await scanPageState()
        sendStep("Scanning page", "success",
          `Captcha image: ${pageState.hasCaptchaImage ? "YES" : "NO"} | Validated: ${pageState.hasCaptchaValidated ? "YES" : "NO"} | Press&Hold: ${pageState.hasPressHold ? "YES" : "NO"} | Create Account: ${pageState.hasCreateAccount ? "YES" : "NO"}`)

        // Step 10: Report captcha status
        if (pageState.hasCaptchaValidated || !pageState.hasCaptchaImage) {
          sendStep("Captcha status", "success", "Captcha validated!")
        } else {
          sendStep("Captcha status", "failed", "Captcha not yet validated after all parallel rounds")
        }

        await new Promise(r => setTimeout(r, 1000))

        // =========================================================================
        // Step 11: PRESS & HOLD (PerimeterX challenge) -- ADVANCED MULTI-STRATEGY
        // =========================================================================
        // <div id="px-captcha"> contains a CLOSED shadow-root with a pill button + hidden iframe.
        // The pill has an accessibility icon on the LEFT. Interactive area is the entire pill.
        // On hold: fills BLACK left-to-right over ~10s. On success: redirect or element removed.
        // On failure: "Please try again" text appears.
        //
        // WHY IT FAILS: PerimeterX detects headless browsers via:
        //   - navigator.webdriver = true (must be patched)
        //   - Missing mouse movement history (must warm up with natural cursor trajectory)
        //   - CDP-level mouse events vs real events (must use multiple strategies)
        //   - Timestamp gaps in events (must use realistic timing)
        //   - Lack of prior page interaction (must simulate human browsing before hold)
        //
        // STRATEGIES (tried in order):
        //   1. Stealth patches + human warm-up + Puppeteer mouse.down/up
        //   2. CDP Input.dispatchMouseEvent (raw Chrome protocol level)
        //   3. JavaScript-injected pointer/touch events on the element
        //   4. Page reload + fresh attempt with different timing
        // =========================================================================

        let pressHoldSolved = false
        const PH_MAX_ATTEMPTS = 4

        if (pageState.hasPressHold && captchaSolved) {
          sendStep("Press & Hold", "running", "Initializing advanced P&H solver...")

          // === PRE-STEP: Apply stealth patches to reduce bot detection ===
          await page.evaluate(() => {
            // Patch webdriver flag (PerimeterX checks this)
            Object.defineProperty(navigator, "webdriver", { get: () => false })

            // Patch chrome object to look like real Chrome
            if (!(window as any).chrome) {
              (window as any).chrome = { runtime: {}, loadTimes: () => ({}), csi: () => ({}) }
            }

            // Patch permissions query
            const origQuery = window.navigator.permissions?.query?.bind(window.navigator.permissions)
            if (origQuery) {
              (window.navigator.permissions as any).query = (params: any) => {
                if (params.name === "notifications") {
                  return Promise.resolve({ state: Notification.permission } as PermissionStatus)
                }
                return origQuery(params)
              }
            }

            // Patch plugins to look like real browser
            Object.defineProperty(navigator, "plugins", {
              get: () => [1, 2, 3, 4, 5].map(() => ({
                name: "Chrome PDF Plugin",
                description: "Portable Document Format",
                filename: "internal-pdf-viewer",
                length: 1,
              })),
            })

            // Patch languages
            Object.defineProperty(navigator, "languages", { get: () => ["en-US", "en"] })
          })
          sendStep("Stealth patches", "success", "Applied webdriver, chrome, plugins, permissions patches")

          // === PRE-STEP: Create CDP session for raw protocol-level mouse events ===
          let cdpSession: any = null
          try {
            cdpSession = await (page as any).createCDPSession()
            sendStep("CDP session", "success", "Created Chrome DevTools Protocol session")
          } catch (e) {
            // Fallback: try target().createCDPSession()
            try {
              cdpSession = await (page as any).target().createCDPSession()
              sendStep("CDP session", "success", "Created CDP session via target()")
            } catch {
              sendStep("CDP session", "failed", "Could not create CDP session, will use Puppeteer mouse only")
            }
          }

          // === Helper: Find #px-captcha coordinates ===
          async function findPxCaptchaRect() {
            return page.evaluate(() => {
              let el = document.getElementById("px-captcha") as HTMLElement | null
              if (!el) {
                const container = document.querySelector(".captcha-text-container")
                if (container) {
                  for (const child of Array.from(container.children)) {
                    const r = (child as HTMLElement).getBoundingClientRect()
                    if (r.height >= 50 && r.width >= 200) { el = child as HTMLElement; break }
                  }
                }
              }
              if (!el) {
                for (const div of Array.from(document.querySelectorAll("div[id*='px'], div[id*='captcha']"))) {
                  const d = div as HTMLElement
                  const r = d.getBoundingClientRect()
                  if (r.height >= 50 && r.height <= 250 && r.width >= 200) { el = d; break }
                }
              }
              if (!el) return null
              const rect = el.getBoundingClientRect()
              return {
                cx: Math.round(rect.x + rect.width * 0.55),
                cy: Math.round(rect.y + rect.height * 0.5),
                x: Math.round(rect.x), y: Math.round(rect.y),
                w: Math.round(rect.width), h: Math.round(rect.height),
                id: el.id || "unknown",
              }
            })
          }

          // === Helper: Check if P&H is solved ===
          async function checkPHSolved(): Promise<{ solved: boolean; reason: string; details: string }> {
            // Check redirect first
            const url = page.url()
            if (!url.includes("register")) {
              return { solved: true, reason: "redirect", details: url.substring(0, 80) }
            }

            const state = await page.evaluate(() => {
              const text = (document.body.innerText || "").toLowerCase()
              const hasPH = text.includes("press & hold") || text.includes("press and hold")
              const hasTryAgain = text.includes("please try again")
              const pxEl = document.getElementById("px-captcha")
              const pxVisible = pxEl ? pxEl.getBoundingClientRect().height > 10 : false

              let createAccountBlue = false
              const allEls = document.querySelectorAll("button, a, input[type='submit'], [role='button'], div, span")
              for (const el of Array.from(allEls)) {
                const t = ((el as HTMLElement).innerText || "").toLowerCase().trim()
                if (t === "create account" || t === "create\naccount") {
                  const style = window.getComputedStyle(el as HTMLElement)
                  const bg = style.backgroundColor || ""
                  const color = style.color || ""
                  const bgRgb = bg.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/)
                  if (bgRgb && parseInt(bgRgb[3]) > parseInt(bgRgb[1]) + 30 && parseInt(bgRgb[3]) > 100) createAccountBlue = true
                  const cRgb = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/)
                  if (cRgb && parseInt(cRgb[3]) > parseInt(cRgb[1]) + 30 && parseInt(cRgb[3]) > 100) createAccountBlue = true
                  const cls = ((el as HTMLElement).className || "").toLowerCase()
                  if (cls.includes("blue") || cls.includes("primary") || cls.includes("active")) createAccountBlue = true
                }
              }

              return { hasPH, hasTryAgain, pxVisible, createAccountBlue }
            })

            const details = `P&H:${state.hasPH} TryAgain:${state.hasTryAgain} pxVisible:${state.pxVisible} blue:${state.createAccountBlue}`

            if (!state.pxVisible) return { solved: true, reason: "px-gone", details }
            if (state.createAccountBlue) return { solved: true, reason: "blue-btn", details }
            if (!state.hasPH && !state.hasTryAgain) return { solved: true, reason: "text-gone", details }
            if (state.hasTryAgain) return { solved: false, reason: "try-again", details }
            return { solved: false, reason: "still-visible", details }
          }

          // === Helper: Human-like mouse warm-up trajectory (builds PerimeterX trust) ===
          async function humanWarmUp(targetX: number, targetY: number) {
            // PerimeterX tracks mouse movement HISTORY. We must build a natural
            // trajectory before the hold to avoid detection.
            const points = [
              { x: 200 + Math.random() * 100, y: 150 + Math.random() * 80 },
              { x: 350 + Math.random() * 150, y: 250 + Math.random() * 100 },
              { x: 500 + Math.random() * 100, y: 200 + Math.random() * 80 },
              { x: targetX - 80 + Math.random() * 30, y: targetY + 60 + Math.random() * 30 },
              { x: targetX - 20 + Math.random() * 10, y: targetY + 15 + Math.random() * 10 },
            ]

            for (const pt of points) {
              await page.mouse.move(pt.x, pt.y, { steps: 3 + Math.floor(Math.random() * 5) })
              await new Promise(r => setTimeout(r, 80 + Math.random() * 200))
            }

            // Final approach to target
            await page.mouse.move(targetX, targetY, { steps: 6 + Math.floor(Math.random() * 4) })
            await new Promise(r => setTimeout(r, 100 + Math.random() * 200))
          }

          // === Helper: Strategy 1 - Puppeteer mouse.down/up ===
          async function strategyPuppeteerMouse(cx: number, cy: number, holdSeconds: number): Promise<void> {
            await page.mouse.down({ button: "left" })
            for (let s = 1; s <= holdSeconds; s++) {
              await new Promise(r => setTimeout(r, 1000))
              sendStep("Pressing & holding", "running", `[Puppeteer] Filling... ${s}/${holdSeconds}s`)
            }
            await page.mouse.up({ button: "left" })
          }

          // === Helper: Strategy 2 - CDP Input.dispatchMouseEvent (raw protocol) ===
          async function strategyCDP(cx: number, cy: number, holdSeconds: number): Promise<void> {
            if (!cdpSession) throw new Error("No CDP session")

            const now = () => Date.now() / 1000 // PerimeterX checks timestamps

            // Mouse pressed
            await cdpSession.send("Input.dispatchMouseEvent", {
              type: "mousePressed",
              x: cx, y: cy,
              button: "left",
              clickCount: 1,
              timestamp: now(),
            })

            // Hold with periodic mouseMoved events (simulates real browser sending move events during hold)
            for (let s = 1; s <= holdSeconds; s++) {
              await new Promise(r => setTimeout(r, 1000))
              // Send a tiny mouseMoved to keep the connection alive (real browsers do this)
              await cdpSession.send("Input.dispatchMouseEvent", {
                type: "mouseMoved",
                x: cx + (Math.random() * 0.5 - 0.25),
                y: cy + (Math.random() * 0.5 - 0.25),
                button: "left",
                timestamp: now(),
              }).catch(() => {})
              sendStep("Pressing & holding", "running", `[CDP] Filling... ${s}/${holdSeconds}s`)
            }

            // Mouse released
            await cdpSession.send("Input.dispatchMouseEvent", {
              type: "mouseReleased",
              x: cx, y: cy,
              button: "left",
              clickCount: 1,
              timestamp: now(),
            })
          }

          // === Helper: Strategy 3 - JavaScript pointer/touch events injected directly ===
          async function strategyJSEvents(cx: number, cy: number, holdSeconds: number): Promise<void> {
            // Dispatch pointer and mouse events via JavaScript at the element coordinates
            await page.evaluate((x: number, y: number) => {
              const el = document.elementFromPoint(x, y) || document.getElementById("px-captcha")
              if (!el) return

              // Full event sequence that a real browser fires
              el.dispatchEvent(new PointerEvent("pointerdown", {
                bubbles: true, cancelable: true, clientX: x, clientY: y,
                pointerId: 1, pointerType: "mouse", isPrimary: true,
                button: 0, buttons: 1, width: 1, height: 1, pressure: 0.5,
              }))
              el.dispatchEvent(new MouseEvent("mousedown", {
                bubbles: true, cancelable: true, clientX: x, clientY: y,
                button: 0, buttons: 1,
              }))
              // Also try touch for hybrid detection
              try {
                const touch = new Touch({ identifier: Date.now(), target: el, clientX: x, clientY: y })
                el.dispatchEvent(new TouchEvent("touchstart", {
                  bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch],
                }))
              } catch {}
            }, cx, cy)

            // Also press via Puppeteer to layer both approaches
            await page.mouse.move(cx, cy)
            await page.mouse.down({ button: "left" })

            for (let s = 1; s <= holdSeconds; s++) {
              await new Promise(r => setTimeout(r, 1000))
              // Send periodic pointermove events via JS
              await page.evaluate((x: number, y: number) => {
                const el = document.elementFromPoint(x, y) || document.getElementById("px-captcha")
                if (!el) return
                el.dispatchEvent(new PointerEvent("pointermove", {
                  bubbles: true, clientX: x + Math.random() * 0.3, clientY: y + Math.random() * 0.3,
                  pointerId: 1, pointerType: "mouse", isPrimary: true, button: 0, buttons: 1, pressure: 0.5,
                }))
              }, cx, cy).catch(() => {})
              sendStep("Pressing & holding", "running", `[JS Events] Filling... ${s}/${holdSeconds}s`)
            }

            await page.mouse.up({ button: "left" })

            // Release events via JS
            await page.evaluate((x: number, y: number) => {
              const el = document.elementFromPoint(x, y) || document.getElementById("px-captcha")
              if (!el) return
              el.dispatchEvent(new PointerEvent("pointerup", {
                bubbles: true, clientX: x, clientY: y,
                pointerId: 1, pointerType: "mouse", isPrimary: true, button: 0,
              }))
              el.dispatchEvent(new MouseEvent("mouseup", {
                bubbles: true, clientX: x, clientY: y, button: 0,
              }))
              try {
                const touch = new Touch({ identifier: Date.now(), target: el, clientX: x, clientY: y })
                el.dispatchEvent(new TouchEvent("touchend", {
                  bubbles: true, changedTouches: [touch],
                }))
              } catch {}
            }, cx, cy).catch(() => {})
          }

          // === Helper: Strategy 4 - Reload page and try with CDP + touch emulation ===
          async function strategyReloadAndTouch(): Promise<boolean> {
            sendStep("Press & Hold", "running", "Strategy 4: Reloading page for fresh attempt...")
            await page.reload({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {})
            await new Promise(r => setTimeout(r, 3000))

            // Re-apply stealth patches after reload
            await page.evaluate(() => {
              Object.defineProperty(navigator, "webdriver", { get: () => false })
              if (!(window as any).chrome) {
                (window as any).chrome = { runtime: {}, loadTimes: () => ({}), csi: () => ({}) }
              }
            })

            // Enable touch emulation via CDP -- makes PerimeterX think it's a touchscreen device
            if (cdpSession) {
              try {
                await cdpSession.send("Emulation.setTouchEmulationEnabled", {
                  enabled: true, maxTouchPoints: 5,
                })
                sendStep("Touch emulation", "success", "Enabled touch emulation")
              } catch {}
            }

            // Wait for P&H to appear
            await new Promise(r => setTimeout(r, 2000))

            const rect = await findPxCaptchaRect()
            if (!rect) return false

            // Scroll into view
            await page.evaluate(() => {
              const el = document.getElementById("px-captcha")
              if (el) el.scrollIntoView({ behavior: "smooth", block: "center" })
            })
            await new Promise(r => setTimeout(r, 1000))

            // Re-find after scroll
            const freshRect = await findPxCaptchaRect()
            const cx = freshRect?.cx ?? rect.cx
            const cy = freshRect?.cy ?? rect.cy

            // Warm up mouse trajectory
            await humanWarmUp(cx, cy)

            // Use touchscreen tap and hold if CDP is available
            if (cdpSession) {
              const now = () => Date.now() / 1000
              try {
                await cdpSession.send("Input.dispatchTouchEvent", {
                  type: "touchStart",
                  touchPoints: [{ x: cx, y: cy, id: 1 }],
                  timestamp: now(),
                })

                for (let s = 1; s <= 11; s++) {
                  await new Promise(r => setTimeout(r, 1000))
                  await cdpSession.send("Input.dispatchTouchEvent", {
                    type: "touchMove",
                    touchPoints: [{ x: cx + Math.random() * 0.3, y: cy + Math.random() * 0.3, id: 1 }],
                    timestamp: now(),
                  }).catch(() => {})
                  sendStep("Pressing & holding", "running", `[Touch CDP] Filling... ${s}/11s`)
                }

                await cdpSession.send("Input.dispatchTouchEvent", {
                  type: "touchEnd",
                  touchPoints: [],
                  timestamp: now(),
                })

                await new Promise(r => setTimeout(r, 3000))
                const check = await checkPHSolved()
                if (check.solved) return true
              } catch (e) {
                sendStep("Touch CDP", "failed", `${e instanceof Error ? e.message.substring(0, 80) : "error"}`)
              }
            }

            // Fallback: puppeteer mouse with longer hold
            await humanWarmUp(cx, cy)
            await page.mouse.down({ button: "left" })
            for (let s = 1; s <= 12; s++) {
              await new Promise(r => setTimeout(r, 1000))
              sendStep("Pressing & holding", "running", `[Reload+Mouse] Filling... ${s}/12s`)
            }
            await page.mouse.up({ button: "left" })
            await new Promise(r => setTimeout(r, 3000))

            // Disable touch emulation after attempt
            if (cdpSession) {
              await cdpSession.send("Emulation.setTouchEmulationEnabled", { enabled: false }).catch(() => {})
            }

            const finalCheck = await checkPHSolved()
            return finalCheck.solved
          }

          // === MAIN PRESS & HOLD LOOP ===
          const strategies = [
            { name: "Puppeteer Mouse", fn: strategyPuppeteerMouse, holdSec: 10 },
            { name: "CDP Protocol", fn: strategyCDP, holdSec: 11 },
            { name: "JS Pointer Events", fn: strategyJSEvents, holdSec: 10 },
          ]

          for (let phAttempt = 1; phAttempt <= PH_MAX_ATTEMPTS && !pressHoldSolved; phAttempt++) {
            // Pre-check: already solved?
            const preCheck = await checkPHSolved()
            if (preCheck.solved) {
              sendStep("Press & Hold", "success", `Already solved: ${preCheck.reason} | ${preCheck.details}`)
              pressHoldSolved = true
              break
            }

            // Strategy 4 (reload + touch) on last attempt
            if (phAttempt === PH_MAX_ATTEMPTS) {
              sendStep("Press & Hold", "running", `Attempt ${phAttempt}/${PH_MAX_ATTEMPTS}: Full reload strategy...`)
              const reloadResult = await strategyReloadAndTouch()
              if (reloadResult) {
                sendStep("Press & Hold", "success", "Reload + touch strategy succeeded!")
                pressHoldSolved = true
                break
              }
              sendStep("Press & Hold", "failed", "Reload strategy also failed")
              break
            }

            // Pick strategy for this attempt
            const strategy = strategies[(phAttempt - 1) % strategies.length]
            sendStep("Press & Hold", "running", `Attempt ${phAttempt}/${PH_MAX_ATTEMPTS}: ${strategy.name} (${strategy.holdSec}s hold)...`)

            // Scroll px-captcha into view
            await page.evaluate(() => {
              const el = document.getElementById("px-captcha")
              if (el) el.scrollIntoView({ behavior: "smooth", block: "center" })
              else window.scrollBy(0, 400)
            })
            await new Promise(r => setTimeout(r, 1200))

            // Find element
            const pxRect = await findPxCaptchaRect()
            if (!pxRect) {
              sendStep("Press & Hold", "failed", `Attempt ${phAttempt}: #px-captcha not found`)
              await new Promise(r => setTimeout(r, 2000))
              continue
            }

            sendStep("Press & Hold", "success",
              `Found #${pxRect.id} ${pxRect.w}x${pxRect.h}. Target: (${pxRect.cx},${pxRect.cy})`)

            // Screenshot before
            const phShot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 50 })
            send({ type: "screenshot", data: `data:image/jpeg;base64,${phShot}` })

            // === HUMAN WARM-UP: build mouse trajectory before pressing ===
            sendStep("Mouse warm-up", "running", "Building natural mouse trajectory...")
            await humanWarmUp(pxRect.cx, pxRect.cy)
            sendStep("Mouse warm-up", "success", "Trajectory built, mouse at target")

            // === EXECUTE STRATEGY ===
            try {
              await strategy.fn(pxRect.cx, pxRect.cy, strategy.holdSec)
              sendStep("Pressing & holding", "success", `${strategy.name}: Released after ${strategy.holdSec}s`)
            } catch (e) {
              sendStep("Pressing & holding", "failed",
                `${strategy.name}: ${e instanceof Error ? e.message.substring(0, 100) : "error"}`)
              // Ensure mouse is released
              await page.mouse.up({ button: "left" }).catch(() => {})
              await new Promise(r => setTimeout(r, 2000))
              continue
            }

            // Wait 3 seconds for page to process
            sendStep("Waiting", "running", "Waiting 3 seconds for page response...")
            await new Promise(r => setTimeout(r, 3000))

            // Check result
            const phResult = await checkPHSolved()
            sendStep("Press & Hold check", "running",
              `Result: ${phResult.reason} | ${phResult.details}`)

            if (phResult.solved) {
              sendStep("Press & Hold", "success", `Solved via ${strategy.name}! (${phResult.reason})`)
              pressHoldSolved = true
              break
            }

            sendStep("Press & Hold", "failed",
              `Attempt ${phAttempt} (${strategy.name}): ${phResult.reason}. Trying next strategy...`)
            await new Promise(r => setTimeout(r, 2000))
          }

          if (!pressHoldSolved) {
            sendStep("Press & Hold", "failed", `All ${PH_MAX_ATTEMPTS} attempts with all strategies failed.`)
          }

          // Cleanup CDP session
          if (cdpSession) {
            try { await cdpSession.detach() } catch {}
          }

          // Screenshot after P&H
          const postPhShot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 50 })
          send({ type: "screenshot", data: `data:image/jpeg;base64,${postPhShot}` })
          await new Promise(r => setTimeout(r, 1000))
        }

        // Step 12: Click CREATE ACCOUNT button (only if not already redirected)
        const currentUrlBeforeSubmit = page.url()
        if (currentUrlBeforeSubmit.includes("register")) {
          // Wait 3 seconds for Create Account button to load/become active after P&H
          await new Promise(r => setTimeout(r, 3000))

          // Re-scan for Create Account button
          sendStep("Clicking submit", "running", "Looking for CREATE ACCOUNT button...")

          const submitClicked = await page.evaluate(() => {
            // Priority 1: "create account" text buttons
            const allBtns = Array.from(document.querySelectorAll("button, a, input[type='submit'], [role='button'], div[onclick], span[onclick]"))
            for (const btn of allBtns) {
              const text = ((btn as HTMLElement).innerText || (btn as HTMLInputElement).value || "").toLowerCase().trim()
              if (text.includes("create account")) {
                (btn as HTMLElement).click()
                return { found: true, text: "create account" }
              }
            }
            // Priority 2: other submit-like buttons
            for (const btn of allBtns) {
              const text = ((btn as HTMLElement).innerText || (btn as HTMLInputElement).value || "").toLowerCase().trim()
              if (text.includes("submit") || text.includes("register") || text.includes("sign up")) {
                (btn as HTMLElement).click()
                return { found: true, text }
              }
            }
            return { found: false, text: "" }
          })

          if (submitClicked.found) {
            sendStep("Clicking submit", "success", `Clicked: "${submitClicked.text}". Waiting for navigation...`)
            await page.waitForNavigation({ timeout: 15000 }).catch(() => {})
          } else {
            sendStep("Clicking submit", "failed", "No submit button found")
          }
        } else {
          sendStep("Clicking submit", "success", `Page already redirected to: ${currentUrlBeforeSubmit.substring(0, 80)}`)
        }

        await new Promise((r) => setTimeout(r, 2000))

        // Take final screenshot (ALWAYS)
        sendStep("Taking screenshot", "running", "Capturing final page state...")
        try {
          const screenshot = await page.screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
          send({ type: "screenshot", data: `data:image/jpeg;base64,${screenshot}` })
          sendStep("Taking screenshot", "success", "Screenshot captured")
        } catch (ssErr) {
          sendStep("Taking screenshot", "failed", `${ssErr instanceof Error ? ssErr.message : "Could not capture"}`)
        }

        await browser.close()
        send({ type: "done", success: true })
      } catch (err) {
        // ALWAYS try to take a screenshot on error before closing
        if (browser) {
          try {
            const pages = await browser.pages()
            if (pages.length > 0) {
              sendStep("Taking screenshot", "running", "Capturing error state...")
              const errScreenshot = await pages[0].screenshot({ encoding: "base64", type: "jpeg", quality: 70 })
              send({ type: "screenshot", data: `data:image/jpeg;base64,${errScreenshot}` })
              sendStep("Taking screenshot", "success", "Error screenshot captured")
            }
          } catch {
            // Screenshot failed, but we still need to report the error
          }
          await browser.close().catch(() => {})
        }
        sendStep("Error", "failed", `${err instanceof Error ? err.message : "Unknown error"}`)
        send({ type: "done", success: false, error: err instanceof Error ? err.message : "Unknown" })
      }

      controller.close()
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}
