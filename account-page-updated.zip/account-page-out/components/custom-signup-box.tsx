"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { CustomSignupForm, type CustomSignupData } from "@/components/custom-signup-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, XCircle, Loader2, CircleDot, Copy, Clock } from "lucide-react"

interface StepResult {
  step: string
  status: "success" | "failed" | "running"
  detail: string
  timestamp?: number
}

interface GeneratedData {
  firstName: string
  lastName: string
  email: string
  phone: string
  password: string
}

export function CustomSignupBox() {
  const [isRunning, setIsRunning] = useState(false)
  const [steps, setSteps] = useState<StepResult[]>([])
  const [screenshot, setScreenshot] = useState<string | null>(null)
  const [resultMessage, setResultMessage] = useState<string | null>(null)
  const [resultSuccess, setResultSuccess] = useState(false)
  const [generatedData, setGeneratedData] = useState<GeneratedData | null>(null)
  const [copied, setCopied] = useState(false)
  const [logCopied, setLogCopied] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const stepsRef = useRef<StepResult[]>([])
  const logEndRef = useRef<HTMLDivElement>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [steps])

  const addStep = useCallback((step: string, status: StepResult["status"], detail: string) => {
    const newStep: StepResult = { step, status, detail, timestamp: Date.now() }
    // Update existing step with same name, or add new
    const existingIdx = stepsRef.current.findIndex((s) => s.step === step)
    if (existingIdx >= 0) {
      stepsRef.current[existingIdx] = newStep
    } else {
      stepsRef.current.push(newStep)
    }
    setSteps([...stepsRef.current])
  }, [])

  const runCustomSignup = useCallback(async (data: CustomSignupData) => {
    setIsRunning(true)
    stepsRef.current = []
    setSteps([])
    setScreenshot(null)
    setResultMessage(null)
    setGeneratedData(null)
    setElapsed(0)

    // Start timer
    const startTime = Date.now()
    timerRef.current = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 1000)), 1000)

    // Create abort controller for stop
    abortRef.current = new AbortController()

    addStep("Connecting", "running", "Starting SSE stream to server...")

    try {
      const response = await fetch("/api/automate-custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: data.url, countryCode: data.country.code, countryDigits: data.country.digits }),
        signal: abortRef.current.signal,
      })

      if (!response.ok || !response.body) {
        const err = await response.text()
        addStep("Connecting", "failed", `Server error: ${err}`)
        setResultSuccess(false)
        setResultMessage("Server error")
        setIsRunning(false)
        if (timerRef.current) clearInterval(timerRef.current)
        return
      }

      addStep("Connecting", "success", "Stream connected, processing...")

      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })

        const lines = buffer.split("\n")
        buffer = lines.pop() || ""

        for (const line of lines) {
          const trimmed = line.trim()
          if (!trimmed.startsWith("data:")) continue
          const jsonStr = trimmed.slice(5).trim()
          if (!jsonStr) continue

          try {
            const event = JSON.parse(jsonStr)

            if (event.type === "step") {
              addStep(event.step, event.status, event.detail)
            } else if (event.type === "generated-data") {
              setGeneratedData(event.data)
            } else if (event.type === "screenshot") {
              setScreenshot(event.data)
            } else if (event.type === "done") {
              if (event.success) {
                setResultSuccess(true)
                setResultMessage("Signup completed successfully!")
              } else {
                setResultSuccess(false)
                setResultMessage(event.error || "Signup failed")
              }
            }
          } catch { /* skip invalid JSON */ }
        }
      }
    } catch (err) {
      if ((err as Error).name !== "AbortError") {
        addStep("Connection", "failed", `Error: ${err instanceof Error ? err.message : "Unknown"}`)
        setResultSuccess(false)
        setResultMessage("Connection error")
      } else {
        addStep("Stopped", "failed", "Process stopped by user")
        setResultMessage("Stopped by user")
        setResultSuccess(false)
      }
    }

    if (timerRef.current) clearInterval(timerRef.current)
    setIsRunning(false)
  }, [addStep])

  const handleStop = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort()
    }
  }, [])

  const copyLogs = () => {
    const text = stepsRef.current
      .map((s) => `[${s.status.toUpperCase()}] ${s.step}\n  ${s.detail}`)
      .join("\n")
    navigator.clipboard.writeText(text)
    setLogCopied(true)
    setTimeout(() => setLogCopied(false), 2000)
  }

  const copyData = () => {
    if (!generatedData) return
    const text = `Name: ${generatedData.firstName} ${generatedData.lastName}\nEmail: ${generatedData.email}\nPhone: ${generatedData.phone}\nPassword: ${generatedData.password}`
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return m > 0 ? `${m}m ${sec}s` : `${sec}s`
  }

  return (
    <Card className="border-border shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-card-foreground flex items-center justify-between">
          <span>WalMart</span>
          {isRunning && (
            <span className="flex items-center gap-1.5 text-[11px] font-normal text-muted-foreground">
              <Clock className="h-3 w-3 animate-pulse" />
              {formatTime(elapsed)}
            </span>
          )}
        </CardTitle>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          Paste signup URL only. Auto-fills random name, @gmail.com, phone (+country code), strong password, captcha.
        </p>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <CustomSignupForm onSubmit={runCustomSignup} onStop={handleStop} isRunning={isRunning} />

        {/* Result message */}
        {resultMessage && !isRunning && (
          <div className={`rounded-lg p-3 text-xs leading-relaxed ${resultSuccess ? "bg-accent/10 text-accent" : "bg-destructive/10 text-destructive"}`}>
            {resultMessage}
            {elapsed > 0 && <span className="ml-2 opacity-70">({formatTime(elapsed)})</span>}
          </div>
        )}

        {/* Generated data card */}
        {generatedData && (
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-card-foreground">Generated Account Data</span>
              <button onClick={copyData} className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-card-foreground transition-colors">
                <Copy className="h-3 w-3" />
                {copied ? "Copied!" : "Copy all"}
              </button>
            </div>
            <div className="flex flex-col gap-1.5 text-[11px] font-mono">
              <div className="flex gap-2"><span className="text-muted-foreground w-16 shrink-0">Name:</span><span className="text-card-foreground">{generatedData.firstName} {generatedData.lastName}</span></div>
              <div className="flex gap-2"><span className="text-muted-foreground w-16 shrink-0">Email:</span><span className="text-card-foreground break-all">{generatedData.email}</span></div>
              <div className="flex gap-2"><span className="text-muted-foreground w-16 shrink-0">Phone:</span><span className="text-card-foreground">{generatedData.phone}</span></div>
              <div className="flex gap-2"><span className="text-muted-foreground w-16 shrink-0">Password:</span><span className="text-card-foreground break-all">{generatedData.password}</span></div>
            </div>
          </div>
        )}

        {/* Live steps log */}
        {steps.length > 0 && (
          <div className="rounded-md border border-border bg-muted/20 overflow-hidden">
            <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-border bg-muted/40">
              <span className="text-[10px] font-semibold text-card-foreground">
                Live Log ({steps.length} steps)
                {isRunning && <span className="ml-1.5 inline-block h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />}
              </span>
              <button onClick={copyLogs} className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-card-foreground transition-colors">
                <Copy className="h-3 w-3" />
                {logCopied ? "Copied!" : "Copy logs"}
              </button>
            </div>
            <div className="flex flex-col gap-0 max-h-[400px] overflow-y-auto p-2.5 font-mono">
              {steps.map((step, index) => (
                <div key={`${step.step}-${index}`} className="flex items-start gap-2 py-0.5">
                  <div className="mt-0.5 shrink-0">
                    {step.status === "success" && <CheckCircle2 className="h-3 w-3 text-accent" />}
                    {step.status === "failed" && <XCircle className="h-3 w-3 text-destructive" />}
                    {step.status === "running" && <Loader2 className="h-3 w-3 animate-spin text-primary" />}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-[11px] font-medium text-card-foreground leading-tight">{step.step}</span>
                    <span className="text-[10px] text-muted-foreground leading-tight break-all">{step.detail}</span>
                  </div>
                </div>
              ))}
              {isRunning && (
                <div className="flex items-start gap-2 py-0.5">
                  <CircleDot className="mt-0.5 h-3 w-3 shrink-0 animate-pulse text-muted-foreground" />
                  <span className="text-[11px] text-muted-foreground">Waiting for next step...</span>
                </div>
              )}
              <div ref={logEndRef} />
            </div>
          </div>
        )}

        {/* Screenshot */}
        {screenshot && (
          <div className="flex flex-col gap-1.5">
            <p className="text-xs font-medium text-card-foreground">Final Screenshot</p>
            <div className="overflow-hidden rounded-md border border-border">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={screenshot} alt="Screenshot after signup" className="w-full" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
