"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Globe, Phone, Loader2, Zap, Square, RefreshCw, Layers, Monitor, ChevronDown } from "lucide-react"
import { COUNTRIES, DEFAULT_COUNTRY, type Country } from "@/lib/countries"

interface AutomationFormProps {
  onSubmit: (url: string, phones: string[], resendCount: number, parallelCount: number, reuseBrowser: boolean, country: Country) => void
  onStop: () => void
  isRunning: boolean
}

export function AutomationForm({ onSubmit, onStop, isRunning }: AutomationFormProps) {
  const [url, setUrl] = useState("")
  const [phonesText, setPhonesText] = useState("")
  const [resendCount, setResendCount] = useState(9)
  const [parallelCount, setParallelCount] = useState(1)
  const [reuseBrowser, setReuseBrowser] = useState(false)
  const [country, setCountry] = useState<Country>(DEFAULT_COUNTRY)
  const [countryOpen, setCountryOpen] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!url || !phonesText.trim() || isRunning) return
    const phones = phonesText
      .split(/[\n,;]+/)
      .map((p) => p.trim().replace(/\D/g, ""))
      .filter((p) => p.length >= 7)
    if (phones.length === 0) return
    onSubmit(url, phones, resendCount, parallelCount, reuseBrowser, country)
  }

  const phoneCount = phonesText
    .split(/[\n,;]+/)
    .map((p) => p.trim().replace(/\D/g, ""))
    .filter((p) => p.length >= 7).length

  const batches = parallelCount > 0 ? Math.ceil(phoneCount / parallelCount) : phoneCount

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {/* Signup URL */}
      <div className="flex flex-col gap-1">
        <Label htmlFor="url" className="text-xs font-medium text-card-foreground">
          Signup URL
        </Label>
        <div className="relative">
          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            id="url"
            type="url"
            placeholder="https://example.com/signup"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="pl-9 h-9 text-sm"
            required
            disabled={isRunning}
          />
        </div>
      </div>

      {/* Country Selector */}
      <div className="flex flex-col gap-1">
        <Label className="text-xs font-medium text-card-foreground">Country Code</Label>
        <div className="relative">
          <button
            type="button"
            onClick={() => !isRunning && setCountryOpen(!countryOpen)}
            disabled={isRunning}
            className="w-full h-9 flex items-center justify-between gap-2 px-3 rounded-md border border-input bg-background text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-accent/10 transition-colors"
          >
            <span className="flex items-center gap-2">
              <span className="text-base leading-none">{country.flag}</span>
              <span className="font-medium text-card-foreground">{country.name}</span>
              <span className="font-mono text-muted-foreground text-xs">{country.code}</span>
            </span>
            <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${countryOpen ? "rotate-180" : ""}`} />
          </button>

          {countryOpen && (
            <div className="absolute z-50 mt-1 w-full rounded-md border border-border bg-popover shadow-lg max-h-52 overflow-y-auto">
              {COUNTRIES.map((c) => (
                <button
                  key={c.iso + c.code}
                  type="button"
                  onClick={() => { setCountry(c); setCountryOpen(false) }}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-accent/10 transition-colors text-left ${c.iso === country.iso && c.code === country.code ? "bg-accent/20" : ""}`}
                >
                  <span className="text-base leading-none">{c.flag}</span>
                  <span className="flex-1 text-card-foreground">{c.name}</span>
                  <span className="font-mono text-xs text-muted-foreground">{c.code}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Phone Numbers */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center justify-between">
          <Label htmlFor="phones" className="text-xs font-medium text-card-foreground">
            Phone Numbers ({country.code}&nbsp;{country.name})
          </Label>
          {phoneCount > 0 && (
            <span className="text-[10px] font-mono text-muted-foreground">
              {phoneCount} number{phoneCount !== 1 ? "s" : ""}
            </span>
          )}
        </div>
        <div className="relative">
          <Phone className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
          <Textarea
            id="phones"
            placeholder={`Local numbers without country code\n5512345678\n5598765432`}
            value={phonesText}
            onChange={(e) => setPhonesText(e.target.value)}
            className="pl-9 min-h-[90px] font-mono text-xs"
            disabled={isRunning}
          />
        </div>
        <p className="text-[9px] text-muted-foreground leading-relaxed">
          Enter local numbers — <span className="font-mono">{country.code}</span> will be prepended automatically.
        </p>
      </div>

      {/* Resend Count + Parallel Count row */}
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1">
          <Label htmlFor="resend" className="text-xs font-medium text-card-foreground">
            OTP Resend Count
          </Label>
          <div className="relative">
            <RefreshCw className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            <Input
              id="resend"
              type="number"
              min={1}
              max={50}
              value={resendCount}
              onChange={(e) => setResendCount(Math.max(1, Math.min(50, parseInt(e.target.value) || 9)))}
              className="pl-8 h-8 text-xs font-mono"
              disabled={isRunning}
            />
          </div>
          <p className="text-[9px] text-muted-foreground">~{resendCount * 11}s per number</p>
        </div>

        <div className="flex flex-col gap-1">
          <Label htmlFor="parallel" className="text-xs font-medium text-card-foreground">
            Parallel at once
          </Label>
          <div className="relative">
            <Layers className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            <Input
              id="parallel"
              type="number"
              min={1}
              max={10}
              value={parallelCount}
              onChange={(e) => setParallelCount(Math.max(1, Math.min(10, parseInt(e.target.value) || 1)))}
              className="pl-8 h-8 text-xs font-mono"
              disabled={isRunning}
            />
          </div>
          <p className="text-[9px] text-muted-foreground">
            {batches > 0 ? `${batches} batch${batches !== 1 ? "es" : ""}` : ""}
            {parallelCount > 1 ? ` of ${parallelCount}` : ""}
          </p>
        </div>
      </div>

      {/* Reuse browser toggle */}
      <div className="flex items-center gap-2 rounded-md border border-border p-2.5">
        <button
          type="button"
          role="switch"
          aria-checked={reuseBrowser}
          onClick={() => setReuseBrowser(!reuseBrowser)}
          disabled={isRunning}
          className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 ${
            reuseBrowser ? "bg-primary" : "bg-muted"
          }`}
        >
          <span
            className={`pointer-events-none block h-3.5 w-3.5 rounded-full bg-card shadow-sm transition-transform duration-200 ${
              reuseBrowser ? "translate-x-[18px]" : "translate-x-[3px]"
            }`}
          />
        </button>
        <div className="flex items-center gap-1.5">
          <Monitor className="h-3.5 w-3.5 text-muted-foreground" />
          <div className="flex flex-col">
            <span className="text-xs font-medium text-card-foreground leading-tight">
              Reuse browser session
            </span>
            <span className="text-[9px] text-muted-foreground leading-tight">
              {reuseBrowser
                ? "One browser, multiple tabs. Saves ~60% RAM."
                : "New browser per number. More stable but uses more RAM."}
            </span>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2">
        <Button
          type="submit"
          className="flex-1 gap-1.5 h-9 text-sm"
          disabled={isRunning || !url || phoneCount === 0}
        >
          {isRunning ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Running...
            </>
          ) : (
            <>
              <Zap className="h-3.5 w-3.5" />
              Start ({phoneCount} numbers, {parallelCount} parallel)
            </>
          )}
        </Button>
        {isRunning && (
          <Button
            type="button"
            variant="destructive"
            className="gap-1.5 h-9 text-sm"
            onClick={onStop}
          >
            <Square className="h-3.5 w-3.5" />
            Stop
          </Button>
        )}
      </div>
    </form>
  )
}
