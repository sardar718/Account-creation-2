"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Globe, Loader2, Zap, Square, ChevronDown } from "lucide-react"
import { COUNTRIES, DEFAULT_COUNTRY, type Country } from "@/lib/countries"

export interface CustomSignupData {
  url: string
  country: Country
}

interface CustomSignupFormProps {
  onSubmit: (data: CustomSignupData) => void
  onStop: () => void
  isRunning: boolean
}

export function CustomSignupForm({ onSubmit, onStop, isRunning }: CustomSignupFormProps) {
  const [url, setUrl] = useState("")
  const [country, setCountry] = useState<Country>(DEFAULT_COUNTRY)
  const [countryOpen, setCountryOpen] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!url || isRunning) return
    onSubmit({ url, country })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {/* Signup URL */}
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="c-url" className="text-xs font-medium text-card-foreground">Signup Page URL</Label>
        <div className="relative">
          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            id="c-url"
            type="url"
            placeholder="https://example.com/register"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="pl-9 h-9 text-sm"
            required
            disabled={isRunning}
          />
        </div>
      </div>

      {/* Country Selector */}
      <div className="flex flex-col gap-1.5">
        <Label className="text-xs font-medium text-card-foreground">Phone Country</Label>
        <div className="relative">
          <button
            type="button"
            onClick={() => !isRunning && setCountryOpen(!countryOpen)}
            disabled={isRunning}
            className="w-full h-9 flex items-center justify-between gap-2 px-3 rounded-md border border-input bg-background text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-accent/10 transition-colors"
          >
            <span className="flex items-center gap-2">
              <span className="text-base leading-none">{country.flag}</span>
              <span className="font-medium text-card-foreground">{country.name}</span>
              <span className="font-mono text-muted-foreground text-xs">{country.code}</span>
            </span>
            <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${countryOpen ? "rotate-180" : ""}`} />
          </button>

          {countryOpen && (
            <div className="absolute z-50 mt-1 w-full rounded-md border border-border bg-popover shadow-lg max-h-52 overflow-y-auto">
              {COUNTRIES.map((c) => (
                <button
                  key={c.iso + c.code}
                  type="button"
                  onClick={() => { setCountry(c); setCountryOpen(false) }}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-accent/10 transition-colors text-left ${c.iso === country.iso && c.code === country.code ? "bg-accent/20" : ""}`}
                >
                  <span className="text-base leading-none">{c.flag}</span>
                  <span className="flex-1 text-card-foreground">{c.name}</span>
                  <span className="font-mono text-xs text-muted-foreground">{c.code}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Auto-generated info */}
      <div className="rounded-md border border-border bg-muted/30 p-2.5">
        <p className="text-[10px] font-medium text-card-foreground mb-1">Auto-generated for each run:</p>
        <ul className="flex flex-col gap-0.5 text-[10px] text-muted-foreground leading-relaxed">
          <li>Random First Name + Last Name</li>
          <li>Random @gmail.com email (e.g. jakeswiftapex472@gmail.com)</li>
          <li>Random phone with <span className="font-mono font-medium text-card-foreground">{country.code}</span> ({country.name})</li>
          <li>Strong 16-char password</li>
          <li>Image captcha solver (4 fallbacks: Tesseract OCR, OCR.space, Canvas extract, AI Vision)</li>
        </ul>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2">
        <Button
          type="submit"
          className="flex-1 gap-1.5 h-9 text-sm"
          disabled={isRunning || !url}
        >
          {isRunning ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Running...
            </>
          ) : (
            <>
              <Zap className="h-3.5 w-3.5" />
              Start Signup
            </>
          )}
        </Button>
        {isRunning && (
          <Button type="button" variant="destructive" className="gap-1.5 h-9 text-sm" onClick={onStop}>
            <Square className="h-3.5 w-3.5" />
            Stop
          </Button>
        )}
      </div>
    </form>
  )
}
