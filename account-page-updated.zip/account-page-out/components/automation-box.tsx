"use client"

import { useState, useCallback, useRef } from "react"
import { AutomationForm } from "@/components/automation-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, XCircle, Loader2, CircleDot } from "lucide-react"

interface StepResult {
  step: string
  status: "success" | "failed" | "running"
  detail: string
}

interface NumberResult {
  phone: string
  email: string
  password: string
  otpCount: number
  status: "pending" | "running" | "done" | "failed"
  error?: string
}

interface AutomationBoxProps {
  boxId: number
}

export function AutomationBox({ boxId }: AutomationBoxProps) {
  const [isRunning, setIsRunning] = useState(false)
  const [steps, setSteps] = useState<StepResult[]>([])
  const [numberResults, setNumberResults] = useState<NumberResult[]>([])
  const stepsMapRef = useRef<Map<string, StepResult>>(new Map())
  const stopRequestedRef = useRef(false)

  const addOrUpdateStep = useCallback((step: string, status: string, detail: string) => {
    const newStep: StepResult = { step, status: status as StepResult["status"], detail }
    stepsMapRef.current.set(step, newStep)
    setSteps(Array.from(stepsMapRef.current.values()))
  }, [])

  async function generateTempEmail(): Promise<{
    email: string; login: string; domain: string; token: string; provider: string
  } | null> {
    try {
      const res = await fetch("/api/tempmail/mailtm", { method: "POST" })
      const data = await res.json()
      if (data.success) return { email: data.email, login: data.login, domain: data.domain, token: data.token, provider: "mailtm" }
    } catch { /* fallthrough */ }
    try {
      const res = await fetch("/api/tempmail/templol", { method: "POST" })
      const data = await res.json()
      if (data.success) return { email: data.email, login: data.login, domain: data.domain, token: data.token, provider: "templol" }
    } catch { /* fallthrough */ }
    try {
      const res = await fetch("/api/tempmail/onesecmail", { method: "POST" })
      const data = await res.json()
      if (data.success) return { email: data.email, login: data.login, domain: data.domain, token: "", provider: "1secmail" }
    } catch { /* fallthrough */ }
    return null
  }

  // Process a single phone number (full pipeline)
  const processOneNumber = useCallback(async (
    url: string, phone: string, index: number, resendCount: number, reuseBrowser: boolean
  ): Promise<NumberResult> => {
    const tag = `[#${index + 1}]`
    const nr: NumberResult = { phone, email: "", password: "", otpCount: 0, status: "running" }

    // 1. Generate temp email
    addOrUpdateStep(`${tag} Temp email`, "running", "Generating...")
    const tempMail = await generateTempEmail()
    if (!tempMail) {
      addOrUpdateStep(`${tag} Temp email`, "failed", "All providers failed")
      nr.status = "failed"
      nr.error = "No temp email"
      return nr
    }
    nr.email = tempMail.email
    addOrUpdateStep(`${tag} Temp email`, "success", `${tempMail.email} (${tempMail.provider})`)

    // 2. Signup automation
    addOrUpdateStep(`${tag} Signup`, "running", "Filling form...")
    try {
      const response = await fetch("/api/automate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, email: tempMail.email, reuseBrowser }),
      })
      const data = await response.json()
      if (!data.success) {
        addOrUpdateStep(`${tag} Signup`, "failed", data.error || "Signup failed")
        nr.status = "failed"
        nr.error = data.error || "Signup failed"
        return nr
      }
      addOrUpdateStep(`${tag} Signup`, "success", "Form submitted!")
    } catch {
      addOrUpdateStep(`${tag} Signup`, "failed", "Connection error")
      nr.status = "failed"
      nr.error = "Connection error"
      return nr
    }

    // 3. Stream confirm + password + 2FA + phone + OTP
    addOrUpdateStep(`${tag} Confirm+OTP`, "running", "Starting...")
    try {
      const streamRes = await fetch("/api/tempmail/confirm-stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: tempMail.provider,
          login: tempMail.login,
          domain: tempMail.domain,
          token: tempMail.token,
          phone,
          resendCount,
          reuseBrowser,
        }),
      })

      if (!streamRes.ok || !streamRes.body) {
        addOrUpdateStep(`${tag} Confirm+OTP`, "failed", "Stream failed")
        nr.status = "failed"
        nr.error = "Stream failed"
        return nr
      }

      const reader = streamRes.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split("\n")
        buffer = ""
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i]
          if (line.startsWith("data: ")) {
            try {
              const event = JSON.parse(line.slice(6))
              if (event.type === "step") {
                addOrUpdateStep(`${tag} ${event.step}`, event.status, event.detail)
              } else if (event.type === "done") {
                if (event.success) {
                  nr.password = event.password || ""
                  nr.otpCount = event.otpCount || 0
                  nr.status = "done"
                } else {
                  nr.status = "failed"
                  nr.error = event.error
                }
              }
            } catch {
              buffer = lines.slice(i).join("\n")
              break
            }
          }
        }
      }
    } catch {
      addOrUpdateStep(`${tag} Confirm+OTP`, "failed", "Stream error")
      nr.status = "failed"
      nr.error = "Stream error"
    }

    return nr
  }, [addOrUpdateStep])

  // Run a batch of numbers in parallel with configurable concurrency
  const runBatch = useCallback(async (
    url: string, phones: string[], resendCount: number, parallelCount: number, reuseBrowser: boolean
  ) => {
    setIsRunning(true)
    stepsMapRef.current.clear()
    setSteps([])
    stopRequestedRef.current = false
    setNumberResults(phones.map((p) => ({ phone: p, email: "", password: "", otpCount: 0, status: "pending" })))

    const finalResults: (NumberResult | null)[] = new Array(phones.length).fill(null)

    // Process in batches of `parallelCount`
    for (let batchStart = 0; batchStart < phones.length; batchStart += parallelCount) {
      if (stopRequestedRef.current) {
        addOrUpdateStep("Stopped", "failed", `Stopped after batch. Remaining numbers skipped.`)
        break
      }

      const batchEnd = Math.min(batchStart + parallelCount, phones.length)
      const batchPhones = phones.slice(batchStart, batchEnd)
      const batchIndices = batchPhones.map((_, i) => batchStart + i)
      const batchNum = Math.floor(batchStart / parallelCount) + 1
      const totalBatches = Math.ceil(phones.length / parallelCount)

      addOrUpdateStep(
        `Batch ${batchNum}/${totalBatches}`,
        "running",
        `Processing ${batchPhones.length} number(s) in parallel: ${batchPhones.join(", ")}`
      )

      // Mark these numbers as running
      setNumberResults((prev) => {
        const updated = [...prev]
        for (const idx of batchIndices) {
          updated[idx] = { ...updated[idx], status: "running" }
        }
        return updated
      })

      // Run all numbers in this batch simultaneously
      const promises = batchPhones.map((phone, i) =>
        processOneNumber(url, phone, batchIndices[i], resendCount, reuseBrowser)
      )

      const batchResults = await Promise.allSettled(promises)

      // Update results
      for (let i = 0; i < batchResults.length; i++) {
        const idx = batchIndices[i]
        const result = batchResults[i]
        if (result.status === "fulfilled") {
          finalResults[idx] = result.value
          setNumberResults((prev) => {
            const updated = [...prev]
            updated[idx] = result.value
            return updated
          })
        } else {
          const failedNr: NumberResult = {
            phone: batchPhones[i], email: "", password: "", otpCount: 0,
            status: "failed", error: "Unexpected error"
          }
          finalResults[idx] = failedNr
          setNumberResults((prev) => {
            const updated = [...prev]
            updated[idx] = failedNr
            return updated
          })
        }
      }

      addOrUpdateStep(
        `Batch ${batchNum}/${totalBatches}`,
        "success",
        `Batch done. ${batchResults.filter((r) => r.status === "fulfilled" && (r.value as NumberResult).status === "done").length}/${batchPhones.length} succeeded.`
      )

      // Small delay between batches
      if (batchEnd < phones.length && !stopRequestedRef.current) {
        await new Promise((r) => setTimeout(r, 2000))
      }
    }

    const doneCount = finalResults.filter((r) => r?.status === "done").length
    addOrUpdateStep("All done", "success", `${doneCount}/${phones.length} numbers completed.`)
    setIsRunning(false)
  }, [processOneNumber, addOrUpdateStep])

  const handleStop = useCallback(() => {
    stopRequestedRef.current = true
    addOrUpdateStep("Stop requested", "running", "Current batch will finish, then stop.")
  }, [addOrUpdateStep])

  return (
    <Card className="border-border shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-card-foreground">
          Bot #{boxId}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <AutomationForm onSubmit={runBatch} onStop={handleStop} isRunning={isRunning} />

        {/* Number summary cards */}
        {numberResults.length > 0 && (
          <div className="flex flex-col gap-1.5">
            <p className="text-xs font-semibold text-muted-foreground">Numbers</p>
            {numberResults.map((nr, i) => (
              <div
                key={i}
                className={`rounded-md border p-2.5 text-xs font-mono ${
                  nr.status === "done"
                    ? "border-accent bg-accent/10"
                    : nr.status === "running"
                    ? "border-primary bg-primary/5"
                    : nr.status === "failed"
                    ? "border-destructive bg-destructive/10"
                    : "border-border bg-muted/30"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-card-foreground truncate">
                    #{i + 1} {nr.phone}
                    {nr.status === "running" && (
                      <Loader2 className="ml-1 inline h-3 w-3 animate-spin text-primary" />
                    )}
                  </span>
                  <span className={`shrink-0 font-semibold ${
                    nr.status === "done" ? "text-accent" :
                    nr.status === "running" ? "text-primary" :
                    nr.status === "failed" ? "text-destructive" :
                    "text-muted-foreground"
                  }`}>
                    {nr.status === "done" ? `${nr.otpCount} OTP done` :
                     nr.status === "running" ? "Running" :
                     nr.status === "failed" ? "Failed" :
                     "Pending"}
                  </span>
                </div>
                {nr.status === "done" && (
                  <div className="mt-1 flex flex-col gap-0.5 text-[10px] text-muted-foreground">
                    <span>Email: {nr.email}</span>
                    {nr.password && <span>Pass: {nr.password}</span>}
                  </div>
                )}
                {nr.status === "failed" && nr.error && (
                  <p className="mt-1 text-[10px] text-destructive">{nr.error}</p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Live steps log */}
        {steps.length > 0 && (
          <div className="flex flex-col gap-0 max-h-[300px] overflow-y-auto rounded-md border border-border bg-muted/20 p-2.5">
            {steps.map((step, index) => (
              <div key={index} className="flex items-start gap-2 py-0.5">
                <div className="mt-0.5 shrink-0">
                  {step.status === "success" && <CheckCircle2 className="h-3 w-3 text-accent" />}
                  {step.status === "failed" && <XCircle className="h-3 w-3 text-destructive" />}
                  {step.status === "running" && <Loader2 className="h-3 w-3 animate-spin text-primary" />}
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-[11px] font-medium text-card-foreground leading-tight">{step.step}</span>
                  <span className="text-[10px] text-muted-foreground truncate leading-tight">{step.detail}</span>
                </div>
              </div>
            ))}
            {isRunning && (
              <div className="flex items-start gap-2 py-0.5">
                <CircleDot className="mt-0.5 h-3 w-3 shrink-0 animate-pulse text-muted-foreground" />
                <span className="text-[11px] text-muted-foreground">Working...</span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
