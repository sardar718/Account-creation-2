"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, XCircle, Loader2, CircleDot, Copy, Check } from "lucide-react"
import { useState } from "react"

export interface StepResult {
  step: string
  status: "success" | "failed" | "running"
  detail: string
}

export interface AutomationResult {
  success: boolean
  error?: string
  message?: string
  steps: StepResult[]
  screenshot?: string
  password?: string
  phone?: string
  otpCount?: number
}

interface AutomationStatusProps {
  steps: StepResult[]
  result: AutomationResult | null
  isRunning: boolean
}

export function AutomationStatus({ steps, result, isRunning }: AutomationStatusProps) {
  const [copied, setCopied] = useState(false)

  const copyPassword = async () => {
    if (result?.password) {
      await navigator.clipboard.writeText(result.password)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  if (steps.length === 0 && !result) return null

  return (
    <Card className="border-border shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-xl font-semibold text-card-foreground">
          {isRunning && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
          {!isRunning && result?.success && <CheckCircle2 className="h-5 w-5 text-accent" />}
          {!isRunning && result && !result.success && <XCircle className="h-5 w-5 text-destructive" />}
          Live Progress
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {/* Steps timeline */}
        <div className="flex flex-col gap-0">
          {steps.map((step, index) => (
            <div key={index} className="flex items-start gap-3 py-2">
              <div className="mt-0.5 shrink-0">
                {step.status === "success" && (
                  <CheckCircle2 className="h-4 w-4 text-accent" />
                )}
                {step.status === "failed" && (
                  <XCircle className="h-4 w-4 text-destructive" />
                )}
                {step.status === "running" && (
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                )}
              </div>
              <div className="flex flex-col gap-0.5 min-w-0">
                <span className="text-sm font-medium text-card-foreground">
                  {step.step}
                </span>
                <span className="text-xs text-muted-foreground truncate">
                  {step.detail}
                </span>
              </div>
            </div>
          ))}
          {isRunning && (
            <div className="flex items-start gap-3 py-2">
              <CircleDot className="mt-0.5 h-4 w-4 shrink-0 animate-pulse text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Working...
              </span>
            </div>
          )}
        </div>

        {/* Final result message */}
        {result && !isRunning && (
          <div
            className={`rounded-lg p-4 text-sm leading-relaxed ${
              result.success
                ? "bg-accent/10 text-accent"
                : "bg-destructive/10 text-destructive"
            }`}
          >
            {result.success
              ? result.message || "Automation completed successfully."
              : result.error || "Something went wrong."}
          </div>
        )}

        {/* Generated password display */}
        {result?.password && !isRunning && (
          <div className="rounded-lg border border-border bg-muted/50 p-4">
            <p className="mb-2 text-sm font-medium text-card-foreground">
              Generated Password -- Save this!
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 rounded-md bg-card px-3 py-2 font-mono text-sm text-card-foreground border border-border select-all">
                {result.password}
              </code>
              <button
                onClick={copyPassword}
                className="shrink-0 rounded-md border border-border bg-card p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-card-foreground"
                aria-label="Copy password"
              >
                {copied ? <Check className="h-4 w-4 text-accent" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>
        )}

        {/* OTP Summary */}
        {result?.phone && result?.otpCount && !isRunning && (
          <div className="rounded-lg border-2 border-accent bg-accent/10 p-5">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-sm">
                <span className="font-medium text-card-foreground">Number:</span>
                <span className="font-mono text-card-foreground">{result.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="font-medium text-card-foreground">OTP:</span>
                <span className="font-mono text-accent font-bold">{result.otpCount} OTP done</span>
              </div>
            </div>
          </div>
        )}

        {/* Screenshot preview */}
        {result?.screenshot && !isRunning && (
          <div className="flex flex-col gap-2">
            <p className="text-sm font-medium text-card-foreground">
              Page Screenshot
            </p>
            <div className="overflow-hidden rounded-lg border border-border">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={result.screenshot}
                alt="Screenshot of the page after automation"
                className="w-full"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
